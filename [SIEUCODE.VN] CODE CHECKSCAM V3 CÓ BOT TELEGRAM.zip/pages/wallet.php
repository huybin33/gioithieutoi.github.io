<?php
require_once('../ketnoi/head.php');
?>
<title> <?=$row['title']; ?> </title>
<?php require_once('../ketnoi/nav.php');
?>
<div id="main" class="main">
    
            <div class="section-banner_child position-relative pseudo vstack justify-content-center text-center" style="background-image: url('https://checkscam.com/assets/default/images/breadcrumb-bg.png')">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="banner-inner position-relative zi-2">
                        <div class="banner-title">
                            CÔNG TY TNHH AN NINH MẠNG CHECKSCAM
                        </div>
                        <div class="banner-description">
                            Nền tảng Website chống lừa đảo giao dịch trực tuyến CHECKSCAM. Kiểm tra, lưu trữ, tố cáo thông tin lừa đảo. An toàn cho bạn giao dịch trực tuyến
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-gap">
        <div class="container">
            <div class="bg-white p-md-4 p-3 rounded-sm border">
                                <div class="col-md-12">
                    <div class="section-heading text-center">
                        <div class="heading-title">Quỹ số dư</div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered template-1-table">
                            <thead>
                            <tr class="bg-theme">
                                <th>Loại</th>
                                <th>Số dư khả dụng</th>
                                <th>Số dư tạm giữ</th>
                                <th>Trạng thái</th>
                                <th style="text-align: right">Chức năng</th>
                            </tr>
                            </thead>
                            <tbody>
                                                                                                <tr>
                                        <td>VND</td>
                                        <td>
                                            <span class="text-success"><b>0đ</b></span>
                                        </td>
                                        <td>
                                <span class="text-danger"><i>0đ</i></span>
                                        </td>
                                        <td><span class="badge badge-success">Hoạt động</span>                                         </td>
                                        <td align="right">
                                            <a href="https://checkscam.com/wallet/history/vnd" style="padding-left: 5px"><span class="btn btn-sm btn-info"><i class="fa fa-history"></i> Lịch sử</span></a>

                                            <a href="https://checkscam.com/wallet/deposit/vnd" style="padding-left: 5px"><span class="btn btn-sm btn-success"><i class="fa fa-plus-circle"></i> Nạp quỹ</span></a>

                                            <a href="https://checkscam.com/wallet/withdraw/vnd" style="padding-left: 5px"><span class="btn btn-sm btn-warning"><i class="fa fa-minus-circle"></i> Rút quỹ</span></a>

                                                                                            <a style="padding-left: 5px" name="VND" link="https://checkscam.com/wallet/del/366" class="deleteClick red id-btn-dialog2" data-toggle="modal" data-target="#deleteModal"><span class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> Xóa quỹ</span></a>
                                                                                    </td>
                                    </tr>
                                                            
                            </tbody>
                        </table>

                    </div>
                </div>

                
            </div>
            <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form id="deleteForm" action="" method="POST">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Xóa quỹ không có số dư</h5>
                            </div>
                            <div id="deleteMes" class="modal-body">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy bỏ</button>
                                <button type="submit" class="btn btn-danger">Xác nhận xóa</button>
                            </div>
                            <input type="hidden" name="_method" value="post">
                            <input type="hidden" name="_token" value="gRXKJE2Romz6copPwHW9CN9fdNEHAuoREtUgg0un">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('../ketnoi/foot.php'); ?>