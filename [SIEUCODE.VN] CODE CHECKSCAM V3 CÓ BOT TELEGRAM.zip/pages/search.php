<?php require_once('../ketnoi/head.php'); ?>
<?php
if (isset($_GET['keyword'])) {
$search = htmlspecialchars($_GET['keyword']);
$sql = mysqli_query($ketnoi, "SELECT * FROM `ticket` WHERE (`stk` like '%$search%') OR (`sdt` like '%$search%') AND `status` = 'scam' ");
$num = mysqli_num_rows($sql);
?>

<title>Kiểm tra</title>
<?php require_once('../ketnoi/nav.php'); ?>
<div id="main" class="main">
    
        
            <h1 class="d-none"></h1>
    <div class="section-tabs">
        <div class="section-search">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10 col-xl-8">
                        <div class="position-relative zi-1">
                            <div class="vstack gap-20px">
                                <div class="section-heading text-center">
                                    <h2 class="heading-title">
                                        KIỂM TRA SCAMMER
                                    </h2>
                                   <?php
                $don_ktm = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'xuly' ")) ['COUNT(*)'];
$don_ktm2 = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `tanthanh` IS NOT NULL"))['COUNT(*)'];
                $don_ktm3 = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'scam' ")) ['COUNT(*)'];
                ?>
                                        <div class="heading-description">
                                            Hiện có <?=$don_ktm3;?> stk, sđt , fb lừa đảo, <?=$don_ktm2;?> tán thành, <?=$don_ktm;?> tố
                                            cáo
                                            đang chờ
                                            duyệt.
                                            <br>Sẽ giúp bạn mua bán an toàn hơn khi online !!!
                                        </div>
                                    </div>
                                <div class="section-form">
                                    <form action="/checkscam" method="GET">
                                        <div class="form-fields hstack">
                                            <input type="text" class="form-control form-fields_input" name="keyword" placeholder="Nhập SĐT, Email hoặc Số tài khoản để kiểm tra...">
                                            <button type="submit" class="button-theme button-theme_secondary" aria-label="Tra cứu">
                                                <i class="fal fa-search"></i>
                                                TRA CỨU
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
            </div>
        </div>
    </div>
    <div class="section-page">
        <div class="section-scam">
            <div class="section-gap">
                <div class="container">
                    <div class="section-heading section-heading_decor text-center">
                        <div class="heading-title">
                            home.title_scam
                        </div>
                    </div>
                                            <div class="alert alert-danger text-center">
                            Có <strong><?=$num;?></strong> vụ lừa đảo liên quan đến: <strong><?=$search;?></strong>
                        </div>
                       
                                            <div class="vstack">
                        <div class="scam-card scam-header">
                            <div class="scam-title scam-column">
                                Người bị tố cáo
                            </div>
                            <div class="scam-column scam-text">
                                Số tiền
                            </div>
                            <div class="scam-column scam-text">
                                SDT
                            </div>
                            <div class="scam-column scam-text">
                                STK
                            </div>
                            <div class="scam-column scam-text">
                                Ngân hàng
                            </div>
                            <div class="scam-column scam-text">
                                Lượt xem
                            </div>
                            <div class="scam-column scam-status">
                                Ngày
                            </div>
                        </div>
                        <?php
$i=1;
foreach( $sql as $chauthebaoktmitvn ) { 
?>
                        
                        <div class="scam-card">
                                    <div class="scam-title scam-column">
                                        <div class="scam-icon me-2">
                                                                                            <i class="fas fa-user-alt"></i>
                                                                                    </div>
                                        <div class="limit">
                                           <?=$chauthebaoktmitvn['username']; ?>
                                        </div>
                                    </div>
                                    <div class="scam-column scam-price">
                                        <?= number_format($chauthebaoktmitvn['sotien'], 0, ',', '.') ?> VNĐ
                                    </div>
                                    <div class="scam-column scam-text">
                                                                                <div class="scam-icon me-2">
                                            <i class="fas fa-phone-alt"></i>
                                        </div>
                                        <?=$chauthebaoktmitvn['sdt']; ?>
                                                                                </div>
                                    <div class="scam-column scam-text">
                                            <?=$chauthebaoktmitvn['stk']; ?>
                                    </div>
                                    <div class="scam-column scam-text">
                                            <?=$chauthebaoktmitvn['ngan_hang']; ?>
                                    </div>
                                    <div class="scam-column scam-text">
                                        <div class="scam-icon me-2">
                                            <i class="fas fa-eye"></i>
                                        </div>
                                     <?=$chauthebaoktmitvn['view']; ?> lượt xem
                                    </div>
                                    <div class="scam-column scam-text">
 <?=$chauthebaoktmitvn['date']; ?>
                                    </div>
                            <a href="/scams/<?=$chauthebaoktmitvn['code']; ?>" class="stretched-link"></a>
                                </div>
                                <?php
}
?>
                                            </div>
                    <div class="section-pagination">
                                            </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('../ketnoi/foot.php'); } ?>