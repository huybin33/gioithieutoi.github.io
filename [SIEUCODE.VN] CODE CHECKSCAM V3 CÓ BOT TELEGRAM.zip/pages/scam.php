<?php
require_once('../ketnoi/head.php');
if (isset($_GET['code'])) {
    $code = $_GET['code'];
}
$result = $ketnoi->query("SELECT * FROM `ticket` WHERE `code` = '$code' AND `status` = 'scam' ");
while($chauthebaoktmitvn = mysqli_fetch_assoc($result)){
mysqli_query($ketnoi, "UPDATE `ticket` SET view = view + 1 WHERE `code` = '$code' ");
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["tanthanh"])) {
mysqli_query($ketnoi, "UPDATE `ticket` SET tanthanh = tanthanh + 1 WHERE `code` = '$code' ");
 echo '<script>
            window.onload = function() {
                alert("Đã tán thành xin cảm ơn bạn!");
            };
          </script>';
    
}
?>

   

<title>Người dùng  <?=$chauthebaoktmitvn['username'];?> Lừa Đảo Với Giá Trị <?= number_format($chauthebaoktmitvn['sotien'], 0, ',', '.') ?> VNĐ !!!</title>
<?php require_once('../ketnoi/nav.php'); ?>
<div id="main" class="main">
    
        
            <h1 class="d-none">Tố cáo Scammer  <?=$chauthebaoktmitvn['username'];?>  </h1>
    <div class="page-scammer">
        <div class="section-tabs">
        <div class="tab-pane fade active show" id="scammer-pill">
            <div class="section-search">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-10 col-xl-8">
                            <div class="position-relative zi-1">
                                <div class="vstack gap-20px">
                                    <div class="section-heading text-center">
                                        <h2 class="heading-title">
                                            KIỂM TRA SCAMMER
                                        </h2>
                                        <div class="heading-description">
                                            Hiện có 35.596 stk, sđt &amp; 4.284 fb lừa đảo, 2.087 bình luận, 64 tố
                                            cáo
                                            đang chờ
                                            duyệt.
                                            <br>Sẽ giúp bạn mua bán an toàn hơn khi online !!!
                                        </div>
                                    </div>
                                    <div class="section-form">
                                        <form action="/checkscam" method="GET">
                                            <div class="form-fields hstack">
                                                <input type="text" class="form-control form-fields_input" name="keyword" value="" placeholder="Nhập SĐT, Email hoặc Số tài khoản để kiểm tra...">
                                                <button type="submit" class="button-theme button-theme_secondary" aria-label="Tra cứu">
                                                    <i class="fal fa-search"></i>
                                                    TRA CỨU
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                                                                                               <div class="text-center" style="padding: 10px"><a href="/posts/to-cao-scam"><button class="btn btn-danger" style="margin-right: 10px"><i class="fal fa-exclamation-triangle"></i> Gửi tố cáo</button></a><a href="/trusted"><button class="btn btn-success"><i class="fa fa-check-circle"></i> Quỹ bảo hiểm</button></a></div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>

        <div class="section-gap">
            <div class="container">
                <div class="row g-4">
                    <div class="col-lg-8 col-xl-9">
                        <div class="vstack gap-30px">
                            <div class="scammer-information">
                                <div class="scammer-header">
                                    Thông tin Scam
                                </div>
                                <div class="scammer-body">
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            <img src="https://checkscam.com/assets/default/images/icon/user.png" class="img-fluid" alt="">
                                                                                            Chủ TK:
                                                                                    </div>
                                        <div class="information-item_value">
                                          <?=$chauthebaoktmitvn['username'];?>                                       </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            <img src="https://checkscam.com/assets/default/images/icon/credit.png" class="img-fluid" alt="">
                                            STK:
                                        </div>
                                        <div class="information-item_value">
                                            <div class="hstack gap-15px">
                                                 <?=$chauthebaoktmitvn['stk'];?>
                                                <button type="button" class="link-default button-copy" data-value="2256671234" data-bs-toggle="tooltip" aria-label="Bấm vào để sao chép">
                                                    <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="699.428px" height="699.428px" viewBox="0 0 699.428 699.428" xml:space="preserve">
                                            <path d="M502.714,0c-2.71,0-262.286,0-262.286,0C194.178,0,153,42.425,153,87.429l-25.267,0.59c-46.228,0-84.019,41.834-84.019,86.838V612c0,45.004,41.179,87.428,87.429,87.428H459c46.249,0,87.428-42.424,87.428-87.428h21.857c46.25,0,87.429-42.424,87.429-87.428v-349.19L502.714,0z M459,655.715H131.143c-22.95,0-43.714-21.441-43.714-43.715V174.857c0-22.272,18.688-42.993,41.638-42.993L153,131.143v393.429C153,569.576,194.178,612,240.428,612h262.286C502.714,634.273,481.949,655.715,459,655.715z M612,524.572c0,22.271-20.765,43.713-43.715,43.713H240.428c-22.95,0-43.714-21.441-43.714-43.713V87.429c0-22.272,20.764-43.714,43.714-43.714H459c-0.351,50.337,0,87.975,0,87.975c0,45.419,40.872,86.882,87.428,86.882c0,0,23.213,0,65.572,0V524.572z M546.428,174.857c-23.277,0-43.714-42.293-43.714-64.981c0,0,0-22.994,0-65.484v-0.044L612,174.857H546.428z M502.714,306.394H306c-12.065,0-21.857,9.77-21.857,21.835c0,12.065,9.792,21.835,21.857,21.835h196.714c12.065,0,21.857-9.771,21.857-21.835C524.571,316.164,514.779,306.394,502.714,306.394z M502.714,415.57H306c-12.065,0-21.857,9.77-21.857,21.834c0,12.066,9.792,21.836,21.857,21.836h196.714c12.065,0,21.857-9.77,21.857-21.836C524.571,425.34,514.779,415.57,502.714,415.57z"></path>
                                        </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            <img src="https://checkscam.com/assets/default/images/icon/bank.png" class="img-fluid" alt="">
                                            Ngân hàng:
                                        </div>
                                        <div class="information-item_value">
                                                                               <?=$chauthebaoktmitvn['ngan_hang'];?>
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            <img src="https://checkscam.com/assets/default/images/icon/price.png" class="img-fluid" alt="">
                                            Số tiền chiếm đoạt:
                                        </div>
                                        <div class="information-item_value">
                                            <div class="information-item_price">
                                                                                    <?= number_format($chauthebaoktmitvn['sotien'], 0, ',', '.') ?> VNĐ
                                                                                             </div>
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            <img src="https://checkscam.com/assets/default/images/icon/list.png" class="img-fluid" alt="">
                                            Hạng mục:
                                        </div>
                                        <div class="information-item_value">
                                                                                                                           <?=$chauthebaoktmitvn['danhmuc'];?>
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            <img src="https://checkscam.com/assets/default/images/icon/image.png" class="img-fluid" alt="">
                                            Ảnh Chụp Bằng Chứng:
                                        </div>
                                        <div class="information-item_value">
                                            <div class="information-item_images">
                                <?php $img = mysqli_query($ketnoi,"SELECT * FROM `bangchung` WHERE `code` = '$code' ORDER BY id desc");while($anhchauthebaoktmitvn = mysqli_fetch_assoc($img)) { ?>
                    <a href="<?=$anhchauthebaoktmitvn['image'];?>" data-fancybox="scammer-images" aria-label="Xem chi tiết" class="initFancybox hstack information-item_image">
                                                    <div class="ratio ratio-1x1">
                                                        <img src="<?=$anhchauthebaoktmitvn['image'];?>" class="img-fluid" alt="">
                                                    </div>
                                                </a>
                                                       <?php } ?>                                    
                                                                                                    
                                            </div>
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            <img src="https://checkscam.com/assets/default/images/icon/content.png" class="img-fluid" alt="">
                                            Nội dung tố cáo:
                                        </div>
                                        <div class="information-item_value">
                                            <p><?=$chauthebaoktmitvn['ly_do'];?></p>
                                                                                    </div>
                                    </div>
                                    <div class="information-item flex-column flex-md-row pt-4 hstack gap-15px justify-content-between">
                                        <div class="information-item_vote hstack gap-20px">
                                            <div class="information-item_vote__approved fw-bold text-success">
                                                <i class="fas fa-thumbs-up"></i>
                                                Tán thành: <?=$chauthebaoktmitvn['tanthanh'];?>
                                            </div>
                                         
                                        </div>
                                        <div class="information-item_report">
                                            <a href="" class="link-default text-secondary">
                                                <i class="fas fa-exclamation-triangle me-1"></i>Yêu cầu gỡ
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="scammer-comments">
                                <div class="section-heading section-heading_small">
                                    <div class="heading-title">
                                        Chọn Tán Thành
                                    </div>
                                </div>
                                                            </div>
                            <div class="section-form">
                                <div class="section-heading section-heading_small">
                                    <div class="heading-title">
                                        Để lại tán thành nếu bạn đồng ý
                                    </div>
                                </div>
                                <div class="section-form_inner">
<form method="post">
                                           
                                        <div class="section-form_item text-center">
                                            <button type="submit" name="tanthanh" class="button-theme button-theme_primary">
                                            Tôi Tán Thành !!!
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-lg-4 col-xl-3">
                        <div class="vstack gap-30px">
                            <div class="scammer-information scammer-information_sidebar">
                                <div class="scammer-header">
                                    Người tố cáo
                                </div>
                                <div class="scammer-body">
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            Họ và tên:
                                        </div>
                                        <div class="information-item_value">
                                              <?=$chauthebaoktmitvn['hoten_np'];?>
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            Zalo liên hệ:
                                        </div>
                                        <div class="information-item_value">
                                                                                            <div class="hstack gap-15px">
                                                                                        <?=substr($chauthebaoktmitvn['sdt_np'], 0, 5).'*****';?>

                                                                                                    </div>
                                                                                    </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            Điểm uy tín:
                                        </div>
                                        <div class="information-item_value">
                                            0
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            Lượt tố cáo
                                        </div>
                                        <div class="information-item_value">
                                            1
                                        </div>
                                    </div>
                                    <div class="information-item hstack gap-15px">
                                        <div class="information-item_title hstack gap-8px">
                                            Ngày tham gia
                                        </div>
                                        <div class="information-item_value">
                                              <?=$chauthebaoktmitvn['ngay'];?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="scammer-related">
                                <div class="section-heading section-heading_small">
                                    <div class="heading-title">
                                        Scammer gần đây
                                    </div>
                                </div>
                                       <?php
$i = 1;
$result = mysqli_query($ketnoi, "SELECT * FROM `ticket` WHERE `status` = 'scam' ORDER BY id desc limit 0, 7");
while ($chauthebaoktmitvn = mysqli_fetch_assoc($result))
{ ?>


                                <div class="scammer-related_list">
                                  <div class="scammer-related_item hstack gap-10px position-relative overflow-hidden">
                                               
                                                <div class="scammer-content">
                                                    <div class="scammer-title">
                                                        <div class="scammer-icon me-2">
                                                            <i class="fas fa-globe"></i>
                                                        </div>
                                                        <div class="scammer-name limit">
                                                            <?=$chauthebaoktmitvn['username']; ?>
                                                        </div>
                                                    </div>
                                                    <div class="scammer-price hstack text-danger">
                                                        <div class="scammer-icon me-2">
                                                            <i class="fas fa-usd-circle"></i>
                                                        </div>
                                                        <?= number_format($chauthebaoktmitvn['sotien'], 0, ',', '.') ?> VNĐ
                                                    </div>
                                                    <div class="scammer-date hstack">
                                                        <div class="scammer-icon me-2">
                                                            <i class="fas fa-calendar-alt"></i>
                                                        </div>
                                                        <?=$chauthebaoktmitvn['ngay']; ?>
                                                    </div>
                                                </div>
                                                <a href="/scams/<?=$chauthebaoktmitvn['code']; ?>" class="stretched-link"></a>
                                            </div>
                                                                                    <div class="scammer-related_item hstack gap-10px position-relative overflow-hidden">

                                                                                                            </div>
                                                                                                                                   <?php } ?>

                            </div>
                            <div class="scammer-photos vstack gap-15px">
                                                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('../ketnoi/foot.php'); } ?>
