<?php require_once('../ketnoi/head.php'); ?>
<title>Bài Báo</title>
<?php require_once('../ketnoi/nav.php'); 
?>
<div id="main" class="main">
                <div class="section-gap section-article">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-heading">
                            <div class="title">
                                Tin tức nổi bật
                            </div>
                            <div class="line"></div>
                            <div class="desc">
                                Các tin tức nổi bật về tình trạng scam hiện nay. Hãy đọc tin tức để phòng hờ các kẻ xấu lợi dụng scam
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="row row-col-10">
                        <?php
$result = mysqli_query($ketnoi, "SELECT * FROM `tintuc` WHERE `status` = 'hoantat' ORDER BY id desc limit 0, 10");
while ($row = mysqli_fetch_assoc($result))
{ ?>
                                                        <div class="col-12 col-sm-6 col-lg-3">
                                <a href="/news/<?=$row['data']; ?>" class="article-card card">
                                    <div class="card-header">
                                        <img src="<?=$row['anh']; ?>"
                                             class="mw-100 image-cover transition-default">
                                    </div>
                                    <div class="card-body py-0 d-flex flex-column">
                                        <div class="card-meta">
                                            Ngày đăng:&nbsp;<?=$row['time']; ?>
                                        </div>
                                        <div class="card-title">
                                        <?=$row['title']; ?>
                                        </div>
                                        <div class="card-text">
                                            
                                        </div>
                                        <div class="card-link mt-auto">
                                            Xem chi tiết <i class="far fa-long-arrow-alt-right"></i>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php
} ?>                                
                                                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php require_once('../ketnoi/foot.php'); ?>