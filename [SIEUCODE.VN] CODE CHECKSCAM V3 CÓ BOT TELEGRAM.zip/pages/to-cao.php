<?php require_once('../ketnoi/head.php'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<title>Tố cáo lừa đảo</title>
<?php require_once('../ketnoi/nav.php'); ?>
<?php
$time = date("h:i:s");
$site = $_SERVER['SERVER_NAME'];
if (isset($_POST["submit"])) {
    $name = [];
    $tmp_name = [];
    $error = [];
    $ext = [];
    $size = [];

    foreach ($_FILES['file']['name'] as $file) {
        $name[] = $file;
    }
    foreach ($_FILES['file']['tmp_name'] as $file) {
        $tmp_name[] = $file;
    }

    for ($i = 0; $i < count($name); $i++) {
        $number_random = random('1234567890', 4);
        $type = htmlspecialchars($_POST['type']);
        $hoten = htmlspecialchars($_POST['hoten']);
        $sotien = htmlspecialchars($_POST['sotien']);
        $sdt = htmlspecialchars($_POST['sdt']);
        $nganhang = htmlspecialchars($_POST['nganhang']);
        $stk = htmlspecialchars($_POST['stk']);
        $lydo = htmlspecialchars($_POST['lydo']);
        $danhmuc = htmlspecialchars($_POST['danhmuc']);
        $nguoi_phot = htmlspecialchars($_POST['hotennp']);
        $linkphot = htmlspecialchars($_POST['linkphot']);
        $sdt_nguoip = $_POST['sdtnp'];

        if (!$type || !$hoten || !$sotien || !$sdt || !$nganhang || !$stk || !$lydo || !$danhmuc || !$nguoi_phot || !$sdt_nguoip) {
            die('<script>swal.fire("Thông Báo", "Vui lòng kiểm tra lại kĩ !", "error");setTimeout(function(){ location.href = "/posts/to-cao-scam" },2000);</script>');
        }

        $ngay = date('d-m-Y');
        $random = random('1234567890', 1);
        $code = xoadau($hoten);

        $temp = preg_split('/[\/\\\\]+/', $name[$i]);
        $filename = $temp[count($temp) - 1];
        $upload_dir = "../storage/";
        $upload_file = $upload_dir . "SC_" . $number_random . ".png";
        if (file_exists($upload_file)) {
            die('<script>swal.fire("Thông Báo", "Ảnh đã tồn tại! Vui lòng thử lại", "error");setTimeout(function(){ location.href = "/service/denounce" },2000);</script>');
        }
        if (move_uploaded_file($tmp_name[$i], $upload_file)) {
            $duong_lik = "/storage/SC_" . $number_random . ".png";
            $getanh = explode(PHP_EOL, $duong_lik);
            $countupdate = 0;

            foreach ($getanh as $row) {
            $ketnoi->query("INSERT INTO `bangchung` SET 
            `code` = '$code',
            `image` = '$row' ");
                $countupdate++;
            }
        }
    }
    $create = $ketnoi->query("INSERT INTO `ticket` SET 
    `type` = '".$type."',
    `username` = '".$hoten."',
    `sotien` = '".$sotien."',
    `ly_do` = '".$lydo."',
     `danhmuc` = '".$danhmuc."',
    `status` = 'xuly',
    `sdt` = '".$sdt."',
    `ngan_hang` = '".$nganhang."',
    `stk` = '".$stk."',
    `code` = '$code',
    `hoten_np` = '".$nguoi_phot."',
    `sdt_np` = '".$sdt_nguoip."',
   `linkphot` = '".$linkphot."',
    `view` = '0',
        `tanthanh` = '0',
    `ngay` = '".$ngay."' ");
    sendTele(templateTele('Scam Bị tố cáo: ' . $hoten . ' Bởi ' . $nguoi_phot));

    die('<script>swal.fire("Thông Báo", "Đã Gửi Thông Tin Thành Công! Chờ Duyệt", "success");setTimeout(function(){ location.href = "/posts/to-cao-scam" },2000);</script>');
}
?>
<div id="main" class="main">
    
        
            <div class="section-gap section-report">
        <form method="post" class="form-theme" enctype="multipart/form-data">
              <div class="container">
                    <div class="section-heading text-center">
                        <div class="heading-title">
                            TỐ CÁO SCAM
                        </div>
                    </div>
                    
                    
                    <div class="row justify-content-center">
                        <div class="col-md-10 col-lg-8">
                            <div class="section-form_inner intermediary-form">
                                <div class="row row-col-10">
                                    <div class="col-md-6 col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label" for="">
                                                    Đối tượng <span class="font-weight-bold text-danger">*</span>
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <select class="form-control" name="type">
                                                    <option value="Cá Nhân">Cá nhân</option>
                                                    <option value="Website">Website</option>
                                                </select>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label">
                                                    CTK / Website <span class="font-weight-bold text-danger">*</span>
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <input type="text" name="hoten" placeholder="Nguyen Van A, abc.com" value="" class="form-theme_item__input form-control" required="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label" for="">
                                                    Số điện thoại
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <input type="text" value="" placeholder="0xxxx" class="form-theme_item__input form-control" name="sdt">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label" for="">
                                                    Số tài khoản <span class="font-weight-bold text-danger">*</span>
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <input type="text" value="" class="form-theme_item__input form-control" name="stk">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label" for="">
                                                    Ngân hàng <span class="font-weight-bold text-danger">*</span>
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <select class="form-select" name="nganhang">
                                                                                                            <option value="VCB">VIETCOMBANK</option>
                                                                                                            <option value="BIDV">BIDV</option>
                                                                                                            <option value="VTB">VIETINBANK</option>
                                                                                                            <option value="AGR">AGRIBANK</option>
                                                                                                            <option value="SAC">SACOMBANK</option>
                                                                                                            <option value="DAB">DONGABANK</option>
                                                                                                            <option value="VPBANK">VPBANK</option>
                                                                                                            <option value="TPBANK">TPBANK</option>
                                                                                                            <option value="EXIM">EXIM BANK</option>
                                                                                                            <option value="SEA">SEABANK</option>
                                                                                                            <option value="KIENLONGBANK">KIENLONGBANK</option>
                                                                                                            <option value="TCB">TECHCOMBANK</option>
                                                                                                            <option value="ABBANK">ABBANK</option>
                                                                                                            <option value="SAIGON">SAIGONBANK</option>
                                                                                                            <option value="MSB">MSB BANK</option>
                                                                                                            <option value="CIMB">CIMB BANK</option>
                                                                                                            <option value="VAB">VAB</option>
                                                                                                            <option value="VIB">VIB BANK</option>
                                                                                                            <option value="SCB">NGÂN HÀNG SÀI GÒN</option>
                                                                                                            <option value="CAKE">CAKE</option>
                                                                                                            <option value="IBK">IBK BANK</option>
                                                                                                            <option value="VRB">Ngân hàng Liên Doanh Việt-Nga</option>
                                                                                                            <option value="NASB">BAC A BANK</option>
                                                                                                            <option value="VIETCAP">VIETCAPITAL BANK</option>
                                                                                                            <option value="BVB">Ngân hàng TMCP Bản Việt</option>
                                                                                                            <option value="LPB">LienVietPost Bank</option>
                                                                                                            <option value="PVCOM">PVCOMBANK</option>
                                                                                                            <option value="OCEAN">OCEANBANK</option>
                                                                                                            <option value="GPB">GP BANK</option>
                                                                                                            <option value="NAMA">NAM Á BANK</option>
                                                                                                            <option value="HDB">HD Bank</option>
                                                                                                            <option value="OCB">OCB BANK</option>
                                                                                                            <option value="MHB">MHB BANK</option>
                                                                                                            <option value="NCB">Ngân Hàng Quốc Dân</option>
                                                                                                            <option value="ACB">Ngân Hàng Á CHÂU</option>
                                                                                                            <option value="VIETBANK">VIETBANK</option>
                                                                                                            <option value="Momo">Ví Momo</option>
                                                                                                            <option value="MB">MB BANK</option>
                                                                                                    </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label" for="">
                                                    Số tiền chiếm đoạt (VND)<span class="font-weight-bold text-danger">*</span>
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <input type="number" value="" min="1000" class="form-theme_item__input form-control" name="sotien" required="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label" for="">
                                                    Danh mục <span class="font-weight-bold text-danger">*</span>
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <select name="danhmuc" class="form-select" required="">
                                                    <option value="">-- Chọn danh mục -- </option>
                                                                                                            <option value="Nick game">Nick game</option>
                                                                                                            <option value="Đầu tư">Đầu tư</option>
                                                                                                            <option value="Nội dung số">Nội dung số</option>
                                                                                                            <option value="Tài khoản MXH">Tài khoản MXH</option>
                                                                                                            <option value="Sim số đẹp">Sim số đẹp</option>
                                                                                                            <option value="Phần mềm">Phần mềm</option>
                                                                                                            <option value="Đổi thẻ cào">Đổi thẻ cào</option>
                                                                                                            <option value="Tiền ảo">Tiền ảo</option>
                                                                                                            <option value="Giao dịch trung gian">Giao dịch trung gian</option>
                                                                                                            <option value="Bán hàng Online">Bán hàng Online</option>
                                                                                                            <option value="Thẻ cào, game">Thẻ cào, game</option>
                                                                                                            <option value="Lừa đảo, cờ bạc">Lừa đảo, cờ bạc</option>
                                                                                                            <option value="Dịch vụ khác">Dịch vụ khác</option>
                                                                                                    </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12 col-12">
    <div class="form-theme_item">
        <div class="form-theme_item__upload">
            <div class="form-theme_item__upload-images">
                <div id="fileInputsContainer">
                    <!-- Initial file input -->
                    <label for="imageInput1">Bằng Chứng 1:</label>
                    <input type="file" id="uploadfile" name="file[]" accept="image/*">
                    <br>

                </div>

                <button type="button" class="btn btn-small btn-success addRow" onclick="addFileInput()">   <i class="fas fa-plus-circle"></i>Thêm Ảnh</button>
            </div>
        </div>
</div>
                            </div>
                            
                                    <div class="col-12 py-0">
                                        <div class="section-form_item">
                                            <small class="form-theme_item__desc px-1 text-muted">
                                                LƯU Ý: Chờ khoảng 15s để Upload ảnh lên sever, bài tố cáo sẽ bị gỡ không upload kèm ảnh, hoặc chứng cứ không đủ thuyết phục.
                                                <br>
                                                Điều 156 Bộ luật Hình sự 2015 (sửa đổi, bổ sung 2017) quy định hành vi vu khống người khác có thể bị phạt tiền từ 10-50 triệu đồng và phạt tù với mức cao nhất từ 03 năm đến 07 năm.
                                            </small>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-12 mb-2">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-lg-12">
                                                <label class="form-label" for="">
                                                    Nội dung tố cáo <span class="font-weight-bold text-danger">*</span>
                                                </label>
                                            </div>
                                            <div class="col-lg-12 mt-1">
                                                <textarea class="form-control" name="lydo" rows="5" style="height: 120px"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-12 mb-2">
                                    <div class="row g-3 align-items-center">
                                        <div class="col-lg-12">
                                            <label class="form-label" for="">
                                                Link nguồn (nếu có)
                                            </label>
                                        </div>
                                        <div class="col-lg-12 mt-1">
                                            <input type="text" value="" class="form-theme_item__input form-control" name="linkphot">
                                        </div>

                                    </div>
                                </div>
                                                                    <div class="row row-col-10">
                                        <div class="col-md-12 col-12 mt-3">
                                            <div class="section-form_item text-center">
                                                <label class="form-label" for="" style="font-size: 1.2em">
                                                    NGƯỜI TỐ CÁO
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12 mb-2">
                                            <div class="row g-3 align-items-center">
                                                <div class="col-lg-12">
                                                    <label class="form-label" for="">
                                                        Họ và tên <span class="font-weight-bold text-danger">*</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-12 mt-1">
                                                    <input type="text" value="" class="form-theme_item__input form-control" name="hotennp" placeholder="Nhập họ tên bạn" required="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12 mb-2">
                                            <div class="row g-3 align-items-center">
                                                <div class="col-lg-12">
                                                    <label class="form-label" for="">
                                                        SDT <span class="font-weight-bold text-danger">*</span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-12 mt-1">
                                                    <input type="text" value="" class="form-theme_item__input form-control" name="sdtnp" placeholder="Nhập số điện thoại của bạn" required="">
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                                                <div class="col-12 mt-4">
                                    <div class="form-theme_item text-center">
                                        <button type="submit" name="submit" class="button-theme button-theme_primary button-theme_medium rounded-2">
                                            GỬI DUYỆT
                                            <span></span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

        </form>

    </div>
</div>
<script>
    var fileInputIndex = 1;
    function addFileInput() {
        fileInputIndex++;
        var container = document.getElementById('fileInputsContainer');
        var label = document.createElement('label');
        label.setAttribute('for', 'imageInput' + fileInputIndex);
        label.textContent = 'Bằng Chứng ' + fileInputIndex + ':';

        var input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('id', 'uploadfile');
        input.setAttribute('name', 'file[]');
        input.setAttribute('accept', 'image/*');

        container.appendChild(label);
        container.appendChild(input);
        container.appendChild(document.createElement('br'));
    }
</script>
<style>
   /* Add this CSS to your stylesheet or in a style tag in your HTML file */

/* Style for the file upload container */
.form-theme_item__upload-images {
    margin-top: 20px;
}

/* Style for the file input label */
.form-theme_item__upload-images label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #333; /* Adjust text color */
}

/* Style for the file input */
.form-theme_item__upload-images input[type="file"] {
    display: block;
    margin-bottom: 15px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: #f8f8f8; /* Adjust background color */
    color: #333; /* Adjust text color */
}

/* Style for the "Thêm Ảnh" button */
.form-theme_item__upload-images button {
    padding: 10px 15px;
    background-color: #4CAF50; /* Green */
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Hover effect for the "Thêm Ảnh" button */
.form-theme_item__upload-images button:hover {
    background-color: #45a049;
}

/* Optional: Style for the added file inputs (if using the addFileInput() function) */
#fileInputsContainer input[type="file"] {
    margin-top: 10px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: #f8f8f8;
    color: #333;
}

</style>
<?php require_once('../ketnoi/foot.php'); ?>