<?php
require_once('../ketnoi/head.php');
?>
<title> <?=$row['title']; ?> </title>
<?php require_once('../ketnoi/nav.php');
?>
<div id="main" class="main">
        
        <div class="section-banner_child position-relative pseudo vstack justify-content-center text-center" style="background-image: url('https://toiuytin.com/assets/default/images/breadcrumb-bg.png')">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="banner-inner position-relative zi-2">
                        <div class="banner-title">
                            <?=$site_tenweb;?>
                        </div>
                        <div class="banner-description">
<?=$site_mota;?>
</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-gap">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-8 col-xl-9">
                    <div class="article-detail">
                        <h1 class="article-title">
                            GIỚI THIỆU <?=$site_tenweb;?>
                        </h1>
                                                    <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                <a href="/">Trang chủ</a>
            </li>
                    <li class="breadcrumb-item">
                <a href="/post/gioi-thieu.html">GIỚI THIỆU <?=$site_tenweb;?></a>
            </li>
            </ol>

                                                <div class="article-content" id="article-content">
                          <?=$site_gioithieu;?>
                                                    </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <div class="sidebar-article">
                        <div class="sidebar-item">
                            <div class="sidebar-header p-3 pb-2">
                                <div class="sidebar-title">
                                    Danh mục
                                </div>
                            </div>
                            <div class="sidebar-body px-3">
                                <div class="sidebar-list">
                                    <ul class="list-unstyled mb-0" id="sidebar-category">
                                                                                                                                    <li>
                                                    <a href="<?=$domainwebsite;?>/trusted" class="footer-list_item--link">
                                                        ĐỘI NGŨ GDV UY TÍN
                                                                                                            </a>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="<?=$domainwebsite;?>/scams" class="footer-list_item--link">
                                                        SCAMMER
                                                                                                            </a>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="<?=$domainwebsite;?>/post/gioi-thieu.html" class="footer-list_item--link">
                                                        GIỚI THIỆU
                                                                                                            </a>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="<?=$domainwebsite;?>/post/dieu-khoan.html" class="footer-list_item--link">
                                                        ĐĂNG KÝ CỌC GDV
                                                                                                            </a>
                                                                                                    </li>
                                                                                                                        </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('../ketnoi/foot.php'); ?>
