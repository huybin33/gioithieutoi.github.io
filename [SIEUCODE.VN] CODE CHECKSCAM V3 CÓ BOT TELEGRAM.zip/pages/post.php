<?php
require_once('../ketnoi/head.php');
if (isset($_GET['code'])) {
    $code = $_GET['code'];
}
$result = $ketnoi->query("SELECT * FROM `tintuc` WHERE `data` = '$code' AND `status` = 'hoantat' ");
while($row = mysqli_fetch_assoc($result)){
mysqli_query($ketnoi, "UPDATE `tintuc` SET view = view + 1 WHERE `data` = '$code' ");
?>
<title> <?=$row['title']; ?> </title>
<?php require_once('../ketnoi/nav.php'); ?>
<div id="main" class="main">
        
        <div class="section-banner_child position-relative pseudo vstack justify-content-center text-center" style="background-image: url('https://toiuytin.com/assets/default/images/breadcrumb-bg.png')">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="banner-inner position-relative zi-2">
                        <div class="banner-title">
                           <?=$site_tenweb;?>
                        </div>
                        <div class="banner-description">
<?=$site_mota;?>
</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-gap">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-8 col-xl-9">
                    <div class="article-detail">
                        <h1 class="article-title">
                            <?=$row['title']; ?>
                        </h1>
                                                    <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                <a href="">Trang chủ</a>
            </li>
                    <li class="breadcrumb-item">
                <a href="">Tin tức</a>
            </li>
            </ol>

                                                <div class="article-content" id="article-content">
<?php 
$lines = explode("\n", $row['note']); 
if (!empty($lines)) {
foreach ($lines as $line) { ?>
<p><?=trim($line);?></p>
<?php
}
}
?>                        </div>
                        <div class="article-bottom">
                            <div class="row g-4 align-items-center flex-column flex-md-row">
                                <div class="col-auto flex-shrink-0 mb-1 mb-md-0">
                                    <div class="article-meta hstack gap-15px">
                                        <div class="article-meta_item">
                                            <i class="far fa-clock"></i>
                                            <span>                                <?=$row['time']; ?></span>
                                        </div>
                                        <div class="article-meta_item">
                                            <i class="far fa-eye"></i>
                                            <span><?=$row['view']; ?> views</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-auto flex-grow-1 d-flex justify-content-md-end">
                                    <div class="article-social">
                                        <ul class="list-unstyled mb-0 d-flex flex-sm-nowrap justify-content-sm-end justify-content-center flex-wrap gap-5px">
                                            

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <div class="sidebar-article">
                        <div class="sidebar-item">
                            <div class="sidebar-header p-3 pb-2">
                                <div class="sidebar-title">
                                    MENU
                                </div>
                            </div>
                            <div class="sidebar-body px-3">
                                <div class="sidebar-list">
                                    <ul class="list-unstyled mb-0" id="sidebar-category">
                                                                                                                                    <li>
                                                    <a href="/trusted" data-bs-toggle="collapse">
                                                        ĐỘI NGŨ GDV UY TÍN
                                                                                                            </a>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/" data-bs-toggle="collapse">
                                                        SCAMMER
                                                                                                            </a>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/post/gioi-thieu.html" data-bs-toggle="collapse">
                                                        GIỚI THIỆU
                                                                                                            </a>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/post/dieu-khoan.html" data-bs-toggle="collapse">
                                                        ĐĂNG KÝ CỌC GDV
                                                                                                            </a>
                                                                                                    </li>
                                                                                                                        </ul>
                                </div>
                            </div>
                        </div>
                        <div class="sidebar-item">
                            <div class="sidebar-header p-3 pb-2">
                                <div class="sidebar-title">
                                    Tin tức khác
                                </div>
                            </div>
                            <div class="sidebar-body pt-2 pb-3 px-3">
                                <div class="sidebar-article">
                                                         <?php
$result = mysqli_query($ketnoi, "SELECT * FROM `tintuc` WHERE `status` = 'hoantat' ORDER BY id desc limit 0, 8");
while ($chauthebaoktmitvn = mysqli_fetch_assoc($result)) { 
?>

<div class="article-item hstack gap-10px position-relative">
                                                <div class="article-item_image flex-shrink-0 ratio ratio-16x9 overflow-hidden">
                                                    <img src="<?=$chauthebaoktmitvn['anh'];?>" class="img-fluid transition-default" alt="">
                                                </div>
                                                <div class="article-item_title limit">
                                               <?=$chauthebaoktmitvn['title'];?>
                                                </div>
                                                <a href="/news/<?=$chauthebaoktmitvn['data'];?>" class="stretched-link" aria-label="<?=$chauthebaoktmitvn['title'];?>"></a>
                                            </div>
                                            <?php
} 
?>


                                                                                                            </div>
                            </div>
                        </div>
                                            </div>
                </div>
            </div>
        </div>
    </div>


</div>
<?php require_once('../ketnoi/foot.php'); } ?>
