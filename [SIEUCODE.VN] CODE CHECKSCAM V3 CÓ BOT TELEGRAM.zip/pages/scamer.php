<?php require_once ('../ketnoi/head.php'); ?>
<title>Trang Chủ</title>
<?php require_once ('../ketnoi/nav.php');
$don = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'scam' ")) ['COUNT(*)'];
?>
 <?php
$sql_total = "SELECT COUNT(*) AS total FROM `ticket` WHERE `status` = 'scam'";
$result_total = mysqli_query($ketnoi, $sql_total);
$row_total = mysqli_fetch_assoc($result_total);
$totalItems = $row_total['total'];

$perPage = 12;

$totalPages = ceil($totalItems / $perPage);

$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($page < 1) {
    $page = 1;
} elseif ($page > $totalPages) {
    $page = $totalPages;
}

$offset = ($page - 1) * $perPage;

$sql = "SELECT * FROM `ticket` WHERE `status` = 'scam' ORDER BY id DESC LIMIT $perPage OFFSET $offset";
$result = mysqli_query($ketnoi, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
    }
} else {
    echo "Không có dữ liệu.";
}

?>
<br>
<br>
<div id="main" class="main">
        
    <h1 class="d-none">Mua bán thẻ điện thoại, thẻ game, nạp tiền topup</h1>
    <div class="section-tabs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link  active " data-bs-toggle="pill"
                                data-bs-target="#scammer-pill" type="button">
                            <i class="fas fa-search"></i>Tra cứu scammer
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link nav-link_secondary " data-bs-toggle="pill"
                                data-bs-target="#uytin-pill">
                            <i class="fas fa-user-alt"></i>Tra cứu bảo hiểm
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="tab-content">
        <div class="tab-pane fade  active show  " id="scammer-pill">
            <div class="section-search">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-10 col-xl-8">
                            <div class="position-relative zi-1">
                                <div class="vstack gap-20px">
                                    <div class="section-heading text-center">
                                        <h2 class="heading-title">
                                            KIỂM TRA SCAMMER
                                        </h2>
                                          <?php
                $don_ktm = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'xuly' ")) ['COUNT(*)'];
$don_ktm2 = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `tanthanh` IS NOT NULL"))['COUNT(*)'];
                $don_ktm3 = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'scam' ")) ['COUNT(*)'];
                ?>
                                        <div class="heading-description">
                                            Hiện có <?=$don_ktm3;?> stk, sđt , fb lừa đảo, <?=$don_ktm2;?> tán thành, <?=$don_ktm;?> tố
                                            cáo
                                            đang chờ
                                            duyệt.
                                            <br>Sẽ giúp bạn mua bán an toàn hơn khi online !!!
                                        </div>
                                    </div>
                                    <div class="section-form">
                                        <form action="/checkscam" method="GET">
                                            <div class="form-fields hstack">
                                                <input type="text" class="form-control form-fields_input" name="keyword" value=""
                                                       placeholder="Nhập SĐT, Email hoặc Số tài khoản để kiểm tra...">
                                                <button type="submit"
                                                        class="button-theme button-theme_secondary"
                                                        aria-label="Tra cứu">
                                                    <i class="fal fa-search"></i>
                                                    TRA CỨU
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                                                           <div class="text-center" style="padding: 10px"><a href="/posts/to-cao-scam"><button class="btn btn-danger" style="margin-right: 10px"><i class="fal fa-exclamation-triangle"></i> Gửi tố cáo</button></a><a href="/trusted"><button class="btn btn-success"><i class="fa fa-check-circle"></i> Quỹ bảo hiểm</button></a></div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade " id="uytin-pill">
            <div class="section-search section-search_secondary">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-10 col-xl-8">
                            <div class="position-relative zi-1">
                                <div class="vstack gap-20px">
                                    <div class="section-heading text-center">
                                        <h2 class="heading-title">
                                            KIỂM TRA BẢO HIỂM
                                        </h2>
                                        <div class="heading-description">
                                            Tham gia chương trình bảo hiểm của <?=$site_tenweb;?> để tạo uy tín trên Internet. Hãy kiểm tra thông tin ở đây trước khi tiến hành giao dịch.
                                        </div>
                                    </div>
                                    <div class="section-form">
                                        <form action="/checkbaohiem" method="GET">
                                            <div class="form-fields hstack">
                                                <input type="text" class="form-control form-fields_input" name="keyword" value=""
                                                       placeholder="Nhập Tên hoặc SDT để kiểm tra...">
                                                <button type="submit"
                                                        class="button-theme button-theme_secondary"
                                                        aria-label="Tra cứu">
                                                    <i class="fal fa-search"></i>
                                                    TRA CỨU
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                                                           <div class="text-center" style="padding: 10px"><a href="/posts/to-cao-scam"><button class="btn btn-danger" style="margin-right: 10px"><i class="fal fa-exclamation-triangle"></i> Gửi tố cáo</button></a><a href="/trusted"><button class="btn btn-success"><i class="fa fa-check-circle"></i> Quỹ bảo hiểm</button></a></div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        
    <div class="section-gap section-scam">
        <div class="container">
            <div class="section-heading section-heading_decor text-center">
                <h2 class="heading-title">
                    Tố cáo mới nhất
                </h2>
                <h3 class="heading-description">
                    Danh sách tố cáo lừa đảo mới nhất
                </h3>
            </div>
            <div class="vstack">
                <div class="scam-card scam-header">
                    <div class="scam-title scam-column">
                        Người bị tố cáo
                    </div>
                    <div class="scam-column scam-text">
                        Số tiền
                    </div>
                    <div class="scam-column scam-text">
                        SDT
                    </div>
                    <div class="scam-column scam-text">
                        STK
                    </div>
                    <div class="scam-column scam-text">
                        Ngân hàng
                    </div>
                    <div class="scam-column scam-text">
                        Lượt xem
                    </div>
                    <div class="scam-column scam-status">
                        Ngày
                    </div>
                </div>
                
                
                <?php
$i = 1;
$result = mysqli_query($ketnoi, "SELECT * FROM `ticket` WHERE `status` = 'scam' ORDER BY id desc limit 0, 10");
while ($chauthebaoktmitvn = mysqli_fetch_assoc($result))
{ ?>


                
                
                
                   <div class="scam-card">
                            <div class="scam-title scam-column">
                                <div class="scam-icon me-2">
                                                                            <i class="fas fa-user-alt"></i>
                                                                    </div>
                                <div class="limit">
                                    <?=$chauthebaoktmitvn['username']; ?>
                                </div>
                            </div>
                            <div class="scam-column scam-price">
<td class="text-center"><?= number_format($chauthebaoktmitvn['sotien'], 0, ',', '.') ?> VNĐ</td>
							                            </div>
                            <div class="scam-column scam-text">
                                                                <div class="scam-icon me-2">
                                    <i class="fas fa-phone-alt"></i>
                                </div>
                                 <?=$chauthebaoktmitvn['sdt']; ?>
                                                                </div>
                            <div class="scam-column scam-text">
                                 <?=$chauthebaoktmitvn['stk']; ?>
                            </div>
                            <div class="scam-column scam-text">
                                  <?=$chauthebaoktmitvn['ngan_hang']; ?>
                            </div>
                            <div class="scam-column scam-text">
                                <div class="scam-icon me-2">
                                    <i class="fas fa-eye"></i>
                                </div>
                                 <?=$chauthebaoktmitvn['view']; ?> lượt xem
                            </div>
                            <div class="scam-column scam-text">
                                <?=$chauthebaoktmitvn['ngay']; ?>
                            </div>
                            <a href="/scams/<?=$chauthebaoktmitvn['code']; ?>" class="stretched-link"></a>
                        </div>
                       <?php } ?>
                  <div class="section-pagination">
    <center>
        <ul class="pagination" role="navigation">
            <li class="page-item">
                <a class="page-link" href="?page=1" rel="prev" aria-label="Previous">‹</a>
            </li>
            <?php if ($totalPages > 1) { ?>
                <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a href="?page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a>
                    </li>
                <?php } ?>
            <?php } ?>
            <li class="page-item">
                <a href="?page=<?php echo $totalPages; ?>" class="page-link">›</a>
            </li>
        </ul>
    </center>
</div>
</div>
</div>
    <?php require_once ('../ketnoi/foot.php'); ?>
