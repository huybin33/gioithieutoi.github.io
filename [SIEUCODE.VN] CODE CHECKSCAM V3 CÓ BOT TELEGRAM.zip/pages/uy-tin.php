<?php require_once('../ketnoi/head.php'); ?>
<title>Quỹ bảo hiểm <?=$site_tenweb;?> - Đảm bảo an toàn giao dịch </title>
<?php require_once('../ketnoi/nav.php'); ?>
<style>.shield-item {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    height: 100%;
    text-align: center;
    gap: 8px;
    position: relative;
    overflow: hidden;
    font-size: .825em;
    line-height: 1.3;
    font-weight: 500;
    -webkit-transition: var(--transition-default);
    -o-transition: var(--transition-default);
    transition: var(--transition-default);</style>
<div id="main" class="main">
    
        
            <h1 class="d-none">Quỹ bảo hiểm Checkscam - Đảm bảo an toàn giao dịch</h1>
    <div class="section-tabs">
        <div class="section-search section-search_secondary">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10 col-xl-8">
                        <div class="position-relative zi-1">
                            <div class="vstack gap-20px">
                                <div class="section-heading text-center">
                                    <h2 class="heading-title">
                                        KIỂM TRA BẢO HIỂM
                                    </h2>
                                     <?php
                $don_ktm = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'xuly' ")) ['COUNT(*)'];
$don_ktm2 = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `tanthanh` IS NOT NULL"))['COUNT(*)'];
                $don_ktm3 = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'scam' ")) ['COUNT(*)'];
                ?>
                                        <div class="heading-description">
                                            Hiện có <?=$don_ktm3;?> stk, sđt , fb lừa đảo, <?=$don_ktm2;?> tán thành, <?=$don_ktm;?> tố
                                            cáo
                                            đang chờ
                                            duyệt.
                                            <br>Sẽ giúp bạn mua bán an toàn hơn khi online !!!
                                        </div>
                                    </div>
                                <div class="section-form">
                                    <form action="/checkbaohiem" method="GET">
                                        <div class="form-fields hstack">
                                            <input type="text" class="form-control form-fields_input" name="keyword" autofocus
                                                   placeholder="Nhập SĐT, Email hoặc Số tài khoản để kiểm tra...">
                                            <button type="submit"
                                                    class="button-theme button-theme_secondary"
                                                    aria-label="Tra cứu">
                                                <i class="fal fa-search"></i>
                                                TRA CỨU
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-tags mt-4">
                <div class="container">
                    <div class="tags-list hstack gap-8px flex-wrap justify-content-center">
                        <a href="/trusted" class="tags-list_item tags-list_active ">Tất cả</a>
                                  <?PHP foreach($ketnoi->query("SELECT * FROM `category` ORDER BY `code` desc") as $cate){ ?>
                                    <a href="<?=$domainwebsite;?>/checkdv?cate=<?=$cate['code'];?>" class="tags-list_item "><?=ucfirst($cate['ten']);?></a>
                                
<?PHP } ?>

                                            </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-gap">
        <div class="container">
            <div class="row g-4 flex-column-reverse flex-md-row">
                <div class="col-lg-3 col-md-4">
                    <div class="sidebar-article">
                                                <div class="sidebar-item">
                            <div class="sidebar-header p-3 pb-2">
                                <h2 class="sidebar-title">
                                    Tin tức mới
                                </h2>
                            </div>
                            
                            
                            

    <div class="sidebar-body pt-2 pb-3 px-3">
        <div class="sidebar-article">
<?php

$result = mysqli_query($ketnoi, "SELECT * FROM `tintuc` WHERE `status` = 'hoantat' ORDER BY id desc limit 0, 8");
while ($check = mysqli_fetch_assoc($result)) { 
?>
<div class="article-item hstack gap-10px position-relative">
                                            <div class="article-item_image flex-shrink-0 ratio ratio-16x9 overflow-hidden">
                                                <img src="<?=$check['anh'];?>" class="img-fluid transition-default" alt="">
                                            </div>
                                            <div class="article-item_title limit">
                                               <?=$check['title'];?>
                                            </div>
                                            <a href="/news/<?=$check['data'];?>" class="stretched-link" aria-label="<?=$check['title'];?>"></a>
                                        </div>
<?php
} 
?>










                    </div>
                </div>
                </div>
                </div>
               </div>
                <div class="col-lg-9 col-md-8">
                    <div class="section-heading section-heading_decor mw-100">
                        <div class="heading-title">
                                                        Danh sách bảo hiểm
                                                        </div>
                                            </div>
 

                                       <?php
                                       $i = 1;
$result = mysqli_query($ketnoi, "SELECT * FROM `cards` ORDER BY id");
?>
<div class="row g-3 g-lg-4 row-cols-xl-10 row-cols-4 row-cols-md-6">
    <?php
while ($check = mysqli_fetch_assoc($result)) {
    if ($check['status'] == null) {
    ?>

        <div class="col">
            <div class="shield-item">
                <div class="ratio ratio-1x1 overflow-hidden rounded-3">
                    <img src="<?= $check['avatar']; ?>" alt="<?= $check['username'] ?>">
                </div>
                <h3 style="font-size: unset;line-height: unset;margin-bottom: 0px">GDV <?= $i++; ?>: <?= $check['username'] ?></h3>
                <a href="/user/<?= $check['code']; ?>" class="stretched-link"></a>
            </div>
        </div>
<?php
    }
}
?>

                    <div class="section-pagination">
                                                    
                                            </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php require_once('../ketnoi/foot.php'); ?>