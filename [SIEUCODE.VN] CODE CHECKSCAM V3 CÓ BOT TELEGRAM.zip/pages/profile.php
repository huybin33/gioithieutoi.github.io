   <?php 
 require_once('../ketnoi/header.php');
 require_once('../ketnoi/nav.php'); 
if (isset($_GET['code'])) {
    $id = $_GET['code'];
}
$result = mysqli_query($ketnoi,"SELECT * FROM `cards` WHERE `code` = '".$id."' ORDER BY id desc limit 0, 1");
while($row = mysqli_fetch_assoc($result))
{
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["uytin"])) {
    mysqli_query($ketnoi, "UPDATE `cards` SET uytin = uytin + 1 WHERE `code` = '$id'");
    echo '<script>
            window.onload = function() {
                alert("Đã cập nhật điểm uy tín !! , load lại trang để cập nhật điểm ' . $uytin . '");
            };
          </script>';
}

?>

    
<title> [ <?=$row['username'];?> ] Administrator NENCER BH  <?= number_format($row['money'], 0, ',', '.') ?> VND</title>
<div id="main" class="main">
    
        
            <h1 class="d-none">[ <?=$row['username'];?> ] Administrator NENCER BH  <?= number_format($row['money'], 0, ',', '.') ?> VND</h1>
            <div class="modal fade modal-qr" id="modal-qr" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <?php
        $result = mysqli_query($ketnoi, "SELECT * FROM `nganhang` WHERE `code` = '" . $id . "' ORDER BY id desc limit 0, 1");
        while ($ndk = mysqli_fetch_assoc($result)) {
        ?>
            <div class="modal-content">
                <div class="modal-body">
                    <div class="modal-icon">
                        <div class="modal-icon_inner">
                            <img src="https://checkscam.com/assets/default/images/icon-qr.png" class="img-fluid" alt="">
                        </div>
                    </div>
                    <div class="modal-title">
                        Scan QR code
                    </div>
                    <div class="modal-text">
                        Scan mã QR để thực hiện chuyển tiền
                    </div>
                    <div class="modal-image">
            <img src="" class="img-fluid" id="img-qr" alt="">
        </div>
                    <div class="modal-button">
                        <button type="button" data-bs-dismiss="modal" class="link-default">
                            Đóng
                        </button>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
    <div class="page-seller">
        <div class="section-gap pt-0">
            <div class="section-banner">
                <div class="container">
                    <div class="ratio">
                                                    <?php
                                                              if ($row['anhbia'] == null) {
                                                                echo '<img src="https://toiuytin.com/assets/default/images/banner-fb.png" class="img-fluid" alt="Dichvuright.com">';
                                                                 } else {
                                                                echo '<img src="'. $row['anhbia'] .'" class="img-fluid" alt="Dichvuright.com">';
                                                                             }
                                                                              ?>
                                                                             
                                            </div>
                </div>
            </div>
               <noscript  type="text/javascript" src="Dichvuright.com"></noscript>
            <div class="seller-information">
                <div class="container">
                    <div class="row g-4">
                        <div class="col-lg-4 col-xl-3">
                            <div class="seller-left">
                                <div class="seller-header">
                                    <div class="seller-avatar">
                                        <div class="ratio ratio-1x1">
                                            <img src="<?=$row['avatar'];?>" class="img-fluid" alt="DichVuRight.Com">
                                             </div>
                    <?php
                                                              if ($row['xt'] == 1) {
                                                                echo '
                                                                <div class="seller-tick">
                                                                <i class="fas fa-check"></i>
                                                                    </div>
                                                                            ';
                                                                 } else {
                                                                echo '';
                                                                             }
?>                                                               

                                                                            </div>
                                    <div class="seller-name">
                                       <?=$row['username'];?>
                                    </div>
<?php
if ($row['goi'] == 1) {
    echo '<div class="seller-sub seller-sub_success ">
    Gói Bạc
    </div>';
} elseif ($row['goi'] == 2) {
    echo '<div class="seller-sub seller-sub_warning ">
    Gói Vàng
    </div>';
} elseif ($row['goi'] == 3) {
    echo '<div class="seller-sub seller-sub_primary">
    Gói Kim Cương
    </div>';
} else {
    echo '<div class="seller-sub ">
    Gói Đồng
    </div>';
}
?>
                                                                        <div class="seller-social">
                                                                                    <a href="https://www.facebook.com/profile.php?id=<?=$row['id_fb'];?>" class="footer-social_item--link" rel="nofollow" target="_blank">
                                                <i class="fab fa-facebook-f"></i>
                                            </a>
                                                                                                                                                                    <a href="dichvuright.com" class="footer-social_item--link" rel="nofollow" target="_blank">
                                                <i class="fab fa-firefox"></i>
                                            </a>
                                                                                                                    </div>
                                </div>
                                <div class="seller-body">
                                    <div class="seller-contact">
                                        <div class="seller-contact_item">
                                            <div class="seller-contact_item__title">
                                                Hotline:
                                            </div>
                                            <div class="seller-contact_item__value hstack gap-8px">
                                                <?=$row['sdt'];?>
                                                                                            </div>
                                        </div>
                                        <div class="seller-contact_item">
                                            <div class="seller-contact_item__title">
                                                Facebook:
                                            </div>
                                            <div class="seller-contact_item__value hstack gap-8px">
												<span class="limit">
													<a href="https://www.facebook.com/profile.php?id=<?=$row['id_fb'];?>" rel="nofollow" target="_blank"><?=$row['id_fb'];?></a>
												</span>
                                            </div>
                                        </div>
                                        <div class="seller-contact_item">
                                            <div class="seller-contact_item__title">
                                                Website:
                                            </div>
                                            <div class="seller-contact_item__value hstack gap-8px">
												<span class="limit">
													<a href="https://<?=$row['website'];?>" rel="nofollow" target="_blank"> <?=$row['website'];?></a>
												</span>
                                            </div>
                                        </div>
                                        <div class="seller-contact_item">
                                            <div class="seller-contact_item__title">
                                                Zalo: 
                                            </div>
                                            <div class="seller-contact_item__value hstack gap-8px">
                                                <?=$row['sdt'];?>
                                                <img src="https://checkscam.com/assets/default/images/icon/check.png" width="18" height="18" class="img-fluid" alt="">
                                                                                            </div>
                                        </div>
                                         <div class="seller-contact_item">
                                            <div class="seller-contact_item__title">
                                                Giấy tờ:
                                            </div>
                                            <div class="seller-contact_item__value hstack gap-8px">
                                                                                                   <?php
                                                              if ($row['xt'] == 1) {
                                                                echo 'Đã xác minh';
                                                                 } else {
                                                                echo 'Chưa xác minh';
                                                                 }
?>                  
                                                                                           
                                        </div>
                                                                            </div>
                                        <div class="seller-contact_item">
                                            <div class="seller-contact_item__title">
                                                Địa chỉ:
                                            </div>
                                            <div class="seller-contact_item__value hstack gap-8px">
                                                                                                   <?php
                                                              if ($row['xt'] == 1) {
                                                                echo 'Đã xác minh';
                                                                 } else {
                                                                echo 'Chưa xác minh';
                                                                 }
?>                  
                                                                                            </div>
                                        </div>
                                                                            </div>
                                    <div class="seller-box">
                                        <div class="seller-box_text">
                                            Bảo hiểm
                                        </div>
                                        <div class="seller-box_value">
                                          <?= number_format($row['money'], 0, ',', '.') ?> VND
                                        </div>
                                        <div class="seller-box_small">
                                                                                    </div>
                                    </div>
                                    <div class="seller-box">
                                        <div class="seller-box_value w-100">
                                            <?php
if ($row['goi'] == 1) {
    echo  '<img src="https://i.imgur.com/btlRWkj.png" alt="Gói">';
} elseif ($row['goi'] == 2) {
    echo '<img src="https://i.imgur.com/IBkyEJB.png" alt="Gói">';
} elseif ($row['goi'] == 3) {
    echo '<img src="https://i.imgur.com/MZxA9O4.png" alt="Gói">';
} else {
    echo '<img src="https://i.imgur.com/btlRWkj.png" alt="Gói">';
}
?>
                                                                                           
                                                                                    </div>
                                    </div>
                                    <div class="seller-box flex-nowrap">
                                                                                    <a type="button" href="https://www.messenger.com/t/<?=$row['id_fb'];?>" class="button-theme button-theme_primary w-100" target="_blank" rel="nofollow">
                                                <i class="fab fa-facebook-messenger"></i>
                                                <span>Check Mess</span>
                                            </a>
                                            <a type="button" href=https://www.facebook.com/<?=$row['id_fb'];?>" class="button-theme button-theme_secondary w-100" target="_blank" rel="nofollow">
                                                <i class="fab fa-facebook-f"></i>
                                                <span>
												Check Fb
											</span>
                                            </a>
                                                                                                                    </div>
                                 <br>
                        <div class="desc">
                            <div style="text-align: center;">
                                <span style="font-size: 1rem;">
                                    <a href="<?=$site['linktele'];?>" target="_blank">
                                        <font color="font-size: 1rem;"><u>
                                            <b>CHECK TRƯỚC KHI GIAO DỊCH</b></u></font></a>
                        </span></div>
                        </div>
                                    <div class="seller-box">
                                        <div class="seller-box_small text-black fw-normal">
                                            <p>
                                            bảo đảm Giao dịch an toàn với người bán này trong giới hạn
                                                bảo hiểm để được an toàn cao nhất
                                            </p>
                                            <p>
                                                <a href="https://toiuytin.com/post/thanh-toan-hoan-tien.html">
                                                    Xem quy định tại đây
                                                </a>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="seller-box">
                                        <div class="seller-box_text">
                                            Điểm uy tín
                                        </div>
                                        <div class="seller-box_value">
                                            : <?=$row['uytin'];?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-xl-9">
                            <div class="seller-right">
                                <div class="seller-introduction">
                                    <div class="seller-heading mb-0">
                                        <div class="seller-heading_title">
                                            Giới thiệu
                                        </div>
                                        <div class="seller-heading_text">
                                           
                       <?=$row['mo_ta'];?>

                                        </div>
                                    </div>
                                </div>
                                 <div class="seller-body vstack gap-25px">
                                    <div class="seller-banks">
                                        <div class="seller-heading">
                                            <div class="seller-heading_title">
                                                Tài khoản ngân hàng
                                            </div>
                                        </div>
                                        <div class="table-responsive bank-table">
                                            <table class="table table-bordered table-hover mb-0 align-middle">
    <thead>
        <tr>
            <th class="text-center">STT</th>
            <th>Ngân hàng</th>
            <th>STK</th>
            <th>Chủ TK</th>
            <th>Cập Nhật</th>
            <th class="text-center">Trạng thái</th>
            <th class="text-center">Mã QR</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $i = 1;
        $danhsach = mysqli_query($ketnoi, "SELECT * FROM nganhang WHERE code = '".$id."' ");
        while ($ndk = mysqli_fetch_assoc($danhsach)) {
            $nganhangArray = explode(',', $ndk['nganhang']);
            $stkArray = explode(',', $ndk['stk']);
            $ctkArray = explode(',', $ndk['ctk']);
            
            $numPairs = count($nganhangArray);
            
            for ($j = 0; $j < $numPairs; $j++) {
                ?>
                <tr>
                    <td class="text-center"><?= $i++; ?></td>
                    <td><?= $nganhangArray[$j]; ?></td>
                    <td><?= $stkArray[$j]; ?></td>
                    <td><?= $ctkArray[$j]; ?></td>
                    <td><?= $ndk['ngay']; ?></td>
                    <td class="text-center">
                        <?php
                        if ($ndk['status'] == null) {
                            echo '<div class="bank-label label-success">Bật</div>';
                        } else {
                            echo '<div class="bank-label label-primary">Tắt</div>';
                        }
                        ?>
                    </td>
                    <td class="text-center">
                        <div class="bank-action">
                            <button type="button" class="link-default btn-qr"
                                data-nganhang="<?= $nganhangArray[$j]; ?>"
                                data-stk="<?= $stkArray[$j]; ?>"
                                data-bs-toggle="modal" data-bs-target="#modal-qr" aria-label="Xem mã QR">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php
            }
        }
        ?>
    </tbody>
</table>

                                        </div>
                                    </div>
                                   <div class="seller-service">
                                        <div class="seller-heading">
                                            <div class="seller-heading_title">
                                                Các dịch vụ
                                            </div>
                                        </div>
                                        <div class="row g-3 row-cols-xl-6 row-cols-3 row-cols-md-4">
                                                                    <?php
$query_combined = "SELECT du.ten AS ID, du.ten AS du_ten, cat.ten AS cat_ten, cat.code, cat.image AS category_image
                  FROM dichvuuser du
                  LEFT JOIN category cat ON FIND_IN_SET(cat.ten, du.ten) > 0
                  WHERE du.code = '".$id."' AND cat.image IS NOT NULL";

$result_combined = mysqli_query($ketnoi, $query_combined);

if ($result_combined) {
    while ($row_combined = mysqli_fetch_assoc($result_combined)) {
        ?>
       <div class="col">
            <div class="topup-card card">
                <div class="card-image">
                    <img src="<?= $row_combined['category_image']; ?>" class="img-fluid" alt="@dichvuright">
                </div>
                <div class="card-title">
                    <?php
                    $atm = $row_combined['du_ten'];
                    $cat_ten = $row_combined['cat_ten'];
                    $delimiters = array(",");
                    $atm = str_replace($delimiters, $delimiters[0], $atm);
                    $arrKeyword = explode($delimiters[0], $atm);
                    foreach ($arrKeyword as $key) {
                        if (strpos($key, $cat_ten) !== false) {
                            echo ''.$key.'';
                        }
                    }
                    ?>
                </div>
                <a href="<?=$domainwebsite;?>/checkdv?cate=<?= $row_combined['code']; ?>" class="stretched-link"></a>
            </div>
        </div>
        <?php
    }
} else {
    echo "Có lỗi xảy ra trong quá trình truy vấn.";
}
?>


                                 </div>
                                    </div>
                                    <noscript  type="text/javascript" src="CHÂU THẾ BẢO , tele @ktmitvn"></noscript>


                                    <div class="section-form">
                                        <div class="section-heading section-heading_small">
                                            <div class="heading-title">
                                                Để lại uy tín !!!
                                            </div>
                                        </div>
                                        <div class="section-form_inner">
                                            <form action="" method="POST">
                                                <div class="section-form_item text-center">
                                            <button type="submit" name="uytin" class="button-theme button-theme_primary">
                                            UY TÍN !!!
                                            </button>
                                        </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var qrButtons = document.querySelectorAll('.btn-qr');

    qrButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var nganhang = button.getAttribute('data-nganhang');
            var stk = button.getAttribute('data-stk');
            var modalNganhang = document.getElementById('modal-nganhang');
            var modalStk = document.getElementById('modal-stk');
            var qrImage = document.getElementById('img-qr');

            if (modalNganhang && modalStk) {
                modalNganhang.innerText = nganhang;
                modalStk.innerText = stk;
            }

            if (qrImage) {
                if (nganhang === "MOMO") {
                    qrImage.src = "https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=2|99|" + stk + "|||0|0|||transfer_myqr";
                } else {
                    qrImage.src = "https://img.vietqr.io/image/" + nganhang + "-" + stk + "-1tPF23Q.jpg";
                }
            }
        });
    });
});
</script>
   <noscript  type="text/javascript" src="CHÂU THẾ BẢO , tele @ktmitvn"></noscript>
<?php require_once('../ketnoi/foot.php'); ?>
<?php } ?>