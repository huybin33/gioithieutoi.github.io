<?php
$domainwebsite = rtrim($_ENV['DOMAIN_WEB'], '/');
define("DATABASE", $_ENV['DB_NAME']);
define("USERNAME", $_ENV['DB_USER']);
define("PASSWORD", $_ENV['DB_PASSWORD']);

$conn = new mysqli("localhost", USERNAME, PASSWORD, DATABASE);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Khai báo các mảng để lưu thông tin về các file
$name = [];
$tmp_name = [];
$error = [];
$ext = [];
$size = [];

// Check if files were uploaded
if (!empty($_FILES['file']['name'][0])) {
    // Iterate over each uploaded file
    for ($i = 0; $i < count($_FILES['file']['name']); $i++) {
        $name[] = $_FILES['file']['name'][$i];
        $tmp_name[] = $_FILES['file']['tmp_name'][$i];
        $error[] = $_FILES['file']['error'][$i];
        $size[] = $_FILES['file']['size'][$i];

        // Extract file extension
        $ext[] = pathinfo($_FILES['file']['name'][$i], PATHINFO_EXTENSION);

        // Process each file here
        $temp = preg_split('/[\/\\\\]+/', $name[$i]);
        $filename = end($temp);

        $upload_dir = "../storage/";
        $number_random = uniqid();
        $upload_file = $upload_dir . "SC_" . $number_random . "." . $ext[$i];

        if (move_uploaded_file($tmp_name[$i], $upload_file)) {
            // File uploaded successfully, you can proceed with further processing
            $duong_lik = "/storage/SC_" . $number_random . "." . $ext[$i];

            // Save information to the database
            $code = "YourCodeValue"; // Replace with your actual code value
            $sql = "INSERT INTO bangchung (code, image) VALUES ('$code', '$duong_lik')";

            if ($conn->query($sql) === TRUE) {
                // Database insertion successful
            } else {
                // Handle database insertion error
                echo json_encode(['success' => false, 'message' => 'Error saving information to the database: ' . $conn->error]);
                exit;
            }
        } else {
            // Handle file upload error
            echo json_encode(['success' => false, 'message' => 'Error uploading file.']);
            exit;
        }
    }

    echo json_encode(['success' => true, 'message' => 'File(s) uploaded and information saved successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'No file uploaded.']);
}

// Close the database connection
$conn->close();
?>
