<?php
require 'config.php';
?>
<!DOCTYPE html>
<?php  
if (isset($_GET['code'])) {
    $id = $_GET['code'];
}
$result = mysqli_query($ketnoi,"SELECT * FROM `cards` WHERE `code` = '".$id."' ORDER BY id desc limit 0, 1");
    $row = mysqli_fetch_assoc($result);
{
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <meta http-equiv="content-language" content="vi" />
        <meta name="robots" content="index, follow'" />
        <meta name="description" content="<?=$_SERVER['HTTP_HOST']?> Cam Kết Bảo Hiểm <?= number_format($row['money'], 0, ',', '.') ?> VND cho mọi giao dịch của bạn với &quot;<?=$row['username' ];?>&quot; khi bạn tuân theo Nội Quy Giao Dịch của <?=$_SERVER['HTTP_HOST']?>" />
        
        <meta name="keywords" content="thẻ điện thoại Viettel, Vinaphone, Mobifone, thẻ game online Pubg, zing, Vcoin, Gate, Carot, Garena, Võ lâm, liên quân" />
        <meta property="og:type" content="[ NENCER ] Administrator NENCER BH  [ <?=$row['username'];?> ] BH <?= number_format($row['money'], 0, ',', '.') ?> VND" />
        <meta property="og:url" content="https://<?=$_SERVER['HTTP_HOST']?>/<?=$row['code'];?>" />
        <meta property="og:image" content="<?=$row['avatar'];?>">
        <meta property="og:description" content="<?=$_SERVER['HTTP_HOST']?> Cam Kết Bảo Hiểm <?= number_format($row['money'], 0, ',', '.') ?> VND cho mọi giao dịch của bạn với &quot;<?=$row['username' ];?>&quot; khi bạn tuân theo Nội Quy Giao Dịch của <?=$_SERVER['HTTP_HOST']?>">
        <meta property="og:site_name" content="Bảo Hiểm Tại <?=$_SERVER['HTTP_HOST']?>" />
        <meta property="article:section" content="[ [ NENCER ] Administrator NENCER BH  [ <?=$row['username'];?> ] BH <?= number_format($row['money'], 0, ',', '.') ?> VND" />
        <meta property="article:tag" content="[ [ NENCER ] Administrator NENCER BH  [ <?=$row['username'];?> ] BH <?= number_format($row['money'], 0, ',', '.') ?> VND" />


        <link rel="icon" href="https://i.imgur.com/2cHiZy2.png" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet" />
<style>
    :root {
        --primary-color: <?=$site_theme;?>;
        --primary-hover: #f0ad4e;
        --primary-rgb: 8, 103, 173;
        --secondary-color: #e85000;
        --secondary-hover: #ee6b20;
        --secondary-rgb: 232, 80, 0;
    }
</style>
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/plugins/swiper/swiper-bundle.min.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/plugins/fancybox/fancybox.min.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/css/base.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/css/style.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/css/custom.css">

        <link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/fonts/fontawesome/css/all.min.css" />
       
          <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
       

        <script type="text/javascript" src="<?=$domainwebsite;?>/assets/default/plugins/select2/js/select2.min.js"></script>
        <script type="text/javascript" src="<?=$domainwebsite;?>/assets/default/plugins/swal/sweetalert2.all.min.js"></script>
        <script type="text/javascript" src="<?=$domainwebsite;?>/assets/default/plugins/cookie/cookie.min.js"></script>
        <script src="<?=$domainwebsite;?>/assets/default/plugins/jquery.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/plugins/bootstrap/bootstrap.bundle.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/plugins/swiper/swiper-bundle.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/plugins/fancybox/fancybox.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/js/app.js"></script>


        <script>
            function onloadCallback() {
                grecaptcha.ready(function () {
                    grecaptcha
                        .execute("", {
                            action: "homepage",
                        })
                        .then(function (token) {
                            $(".recaptcha_token").val(token);
                        });
                });
            }
            function HideModal() {
                Cookies.set("Hide", "TRUE", { expires: 1 });
                $("#global-modal").modal("hide");
            }
            $(document).ready(function () {
                if (!Cookies.get("Hide")) {
                    $("#global-modal").modal("show");
                }
                $("#dropfile").click(function (event) {
                    $("#uploadfile").trigger("click");
                });
            });

        </script>
   <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
</head>
<?php } ?>
