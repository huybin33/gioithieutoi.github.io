   <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript><body>
  <div id="header" class="header">
    <div class="header-main">
        <div class="container">
            <div class="row flex-lg-nowrap justify-content-between align-items-center">
                <div class="col-lg-auto col-xl-3 col-5 order-1 order-lg-1">
                    <div class="header-logo">
                        <a href="<?=$domainwebsite;?>" aria-label="" class="hstack align-items-center">
                            <img src="<?=$site_logo;?>" class=""
                                 alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-auto col-xl-6 col-12 order-3 order-lg-2">
                    <div class="header-navigation" id="header-navigation">
                        <ul>
        <li class="navigation-logo d-flex d-lg-none">
            <a href="<?=$domainwebsite;?>"
               class="d-inline-flex align-items-center justify-content-center align-middle"
               data-href="/">
                <img src="<?=$site_logo;?>" class="img-fluid" alt="">
            </a>
        </li>
           <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
                    <li>
                <a  href="<?=$domainwebsite;?>/trusted" >
                    ĐỘI NGŨ GDV UY TÍN
                                    </a>
                            </li>
                    <li>
                <a  href="/" >
                    SCAMMER
                                    </a>
                            </li>
                    <li>
                <a  href="<?=$domainwebsite;?>/post/gioi-thieu.html" >
                    GIỚI THIỆU
                                    </a>
                            </li>
                    <li>
                <a  href="<?=$domainwebsite;?>/post/dieu-khoan.html" >
                    ĐĂNG KÝ CỌC GDV
                                    </a>
                            </li>
            </ul>


                    </div>
                </div>
                <div class="col-lg-auto col-xl-3 col-7 order-2 order-lg-3">
                    <div class="header-actions hstack gap-8px justify-content-end">
                        <div class="header-users hstack gap-8px">
                            <div class="header-user_item position-relative">
                                <a href="<?=$domainwebsite;?>/posts/to-cao-scam" class="button-theme button-theme_primary"
                                   aria-label="Tố cáo">
                                    <i class="fal fa-exclamation-triangle"></i>
                                    <span>
										Tố cáo
									</span>
                                </a>
                            </div>
                               <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
                                                            <div class="header-user_item position-relative">
                                    <a href="<?=$domainwebsite;?>/account/login" class="button-theme button-theme_default" aria-label="Đăng nhập">
                                        <i class="fal fa-user-alt"></i>
                                    </a>
                                </div>
                                
                        </div>
                           <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
                        <div class="header-hamburger d-flex d-lg-none">
                            <button type="button" class="hamburger-button" id="hamburger-button">
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-overlay" id="header-overlay"></div>
</div>
   </header>
      <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>