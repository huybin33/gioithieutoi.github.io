<!--
//////////////////////////////////////////////////////////////////////
// Bạn là Con Người Thông Minh Sẽ Không Làm Điều Đó, Tôi Quý Bạn  ////
//        Khi Bạn Không F12 </> Chỉ Có Súc Vật Mới F12!!!         ////
//                                                                ////
//                          _ooOoo_                               ////
//                         o8888888o                              ////
//                         88" . "88                              ////
//                         (| ^_^ |)                              ////
//                         O\  =  /O                              ////
//                      ____/`---'\____                           ////
//                    .'  \\|     |//  `.                         ////
//                   /  \\|||  :  |||//  \                        ////
//                  /  _||||| -:- |||||-  \                       ////
//                  |   | \\\  -  /// |   |                       ////
//                  | \_|  ''\---/''  |   |                       ////
//                  \  .-\__  `-`  ___/-. /                       ////
//                ___`. .'  /--.--\  `. . ___                     ////
//              ."" '<  `.___\_<|>_/___.'  >'"".                  ////
//            | | :  `- \`.;`\ _ /`;.`/ - ` : | |                 ////
//            \  \ `-.   \_ __\ /__ _/   .-` /  /                 ////
//      ========`-.____`-.___\_____/___.-`____.-'========         ////
//                           `=---='                              ////
//      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^        ////
//          Quay đầu là bờ , Mau Tắt Đi Thk Lol                   ////
//                                                                ////
//////////////////////////////////////////////////////////////////////
https://facebook.com/dichvuright
-->
<?php
require 'config.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <meta http-equiv="content-language" content="vi" />
        <meta name="robots" content="index, follow'" />

       <meta name="description" content="<?=$site_mota;?>">
<meta name="keywords" content="thẻ điện thoại Viettel, Vinaphone, Mobifone, thẻ game online Pubg, zing, Vcoin, Gate, Carot, Garena, Võ lâm, liên quân">

<!-- Open Graph data -->
<meta property="og:title" content="<?=$site_mota;?>.">
<meta property="og:type" content="Website">
<meta property="og:url" content=" <?=$domainwebsite;?>">
<meta property="og:image" content="<?=$site['banner'];?>">
<meta property="og:description" content="<?=$site_mota;?>.">
<meta property="og:site_name" content="Mua bán thẻ điện thoại, thẻ game, nạp tiền topup">
<meta property="article:section" content="<?=$site_mota;?>.">
<meta property="article:tag" content="thẻ điện thoại Viettel, Vinaphone, Mobifone, thẻ game online Pubg, zing, Vcoin, Gate, Carot, Garena, Võ lâm, liên quân">

<!-- Twitter Card data -->
<meta name="twitter:card" content="<?=$site['banner'];?>">
<meta name="twitter:site" content="@dichvuright">
<meta name="twitter:title" content="Mua bán thẻ điện thoại, thẻ game, nạp tiền topup">
<meta name="twitter:description" content="<?=$site_mota;?>.">
<meta name="twitter:creator" content="@dichvuright">
<meta name="twitter:image:src" content="<?=$site['banner'];?>">
<link rel="alternate" hreflang="vi-vn" href="<?=$domainwebsite;?>">
<link rel="canonical" href="<?=$domainwebsite;?>">


        <link rel="icon" href="https://i.imgur.com/2cHiZy2.png" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet" />
<style>
    :root {
        --primary-color: <?=$site_theme;?>;
        --primary-hover: #f0ad4e;
        --primary-rgb: 8, 103, 173;
        --secondary-color: #e85000;
        --secondary-hover: #ee6b20;
        --secondary-rgb: 232, 80, 0;
    }
</style>
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/plugins/swiper/swiper-bundle.min.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/plugins/fancybox/fancybox.min.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/css/base.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/css/style.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/dropzone/dropzone.css">
<link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/css/custom.css">

        <link rel="stylesheet" href="<?=$domainwebsite;?>/assets/default/fonts/fontawesome/css/all.min.css" />
       
          <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
       

        <script type="text/javascript" src="<?=$domainwebsite;?>/assets/default/plugins/select2/js/select2.min.js"></script>
        <script type="text/javascript" src="<?=$domainwebsite;?>/assets/default/plugins/swal/sweetalert2.all.min.js"></script>
        <script type="text/javascript" src="<?=$domainwebsite;?>/assets/default/plugins/cookie/cookie.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/plugins/bootstrap/bootstrap.bundle.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/plugins/swiper/swiper-bundle.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/plugins/fancybox/fancybox.min.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/dropzone/dropzone.js"></script>
<script src="<?=$domainwebsite;?>/assets/default/js/app.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


        <script>
            function onloadCallback() {
                grecaptcha.ready(function () {
                    grecaptcha
                        .execute("", {
                            action: "homepage",
                        })
                        .then(function (token) {
                            $(".recaptcha_token").val(token);
                        });
                });
            }
            function HideModal() {
                Cookies.set("Hide", "TRUE", { expires: 1 });
                $("#global-modal").modal("hide");
            }
            $(document).ready(function () {
                if (!Cookies.get("Hide")) {
                    $("#global-modal").modal("show");
                }
                $("#dropfile").click(function (event) {
                    $("#uploadfile").trigger("click");
                });
            });

        </script>
   <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
</head>
