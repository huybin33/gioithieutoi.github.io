<footer id="footer" class="footer">
    <div class="footer-main section-gap">
        <div class="position-relative zi-2">
            <div class="container">
                <div class="row g-4">
                    <div class="col-lg-3 col-6 order-2">
            <div class="footer-title">
                Chính sách
            </div>
                        <ul class="footer-list footer-link list-unstyled mb-0">
                                <li class="footer-list_item">
                    <a href="/post/dieu-khoan.html" class="footer-list_item--link">
                        Tham gia bảo hiểm
                    </a>
                </li>
                                <li class="footer-list_item">
                    <a href="" class="footer-list_item--link">
                        Xử lý tranh chấp
                    </a>
                </li>
                                <li class="footer-list_item">
                    <a href="/posts/to-cao-scam.html" class="footer-list_item--link">
                        Báo cáo vi phạm
                    </a>
                </li>
                                <li class="footer-list_item">
                    <a href="" class="footer-list_item--link">
                        Bảo mật thông tin
                    </a>
                </li>
                            </ul>
                        </div>
            <div class="col-lg-3 col-6 order-2">
            <div class="footer-title">
                Thông tin
            </div>
                        <ul class="footer-list footer-link list-unstyled mb-0">
                                <li class="footer-list_item">
                    <a href="/post/gioi-thieu.html" class="footer-list_item--link">
                        Giới thiệu
                    </a>
                </li>
                                <li class="footer-list_item">
                    <a href="/" class="footer-list_item--link">
                        Tin tức
                    </a>
                </li>
                                <li class="footer-list_item">
                    <a href="/trusted" class="footer-list_item--link">
                        Quỹ bảo hiểm CS
                    </a>
                </li>
                                <li class="footer-list_item">
                    <a href="" class="footer-list_item--link">
                        Gói bảo hiểm
                    </a>
                </li>
                                <li class="footer-list_item">
                    <a href="   " class="footer-list_item--link">
                        Kiểm tra Scam
                    </a>
                </li>
                            </ul>
                        </div>
    
                    <div class="col-lg-3 col-6 order-1 order-lg-4">
                        <div class="footer-item">
                            <div class="footer-title">
                                CÔNG TY TNHH AN NINH MẠNG CHECKSCAM
                            </div>
                            <ul class="footer-list list-unstyled mb-0">
                                <li class="footer-list_item">
                                    <a href="javascript:false" class="footer-list_item--link">
                                        <i class="fas fa-map-marker-alt"></i>
                                       Việt Nam
                                    </a>
                                </li>
                                <li class="footer-list_item">
                                    <a href="tel:<?=$site_sdt_momo;?>" class="footer-list_item--link">
                                        <i class="fas fa-phone-rotary"></i><?=$site_sdt_momo;?>
                                    </a>
                                </li>
                                <li class="footer-list_item">
                                    <a href="tel:0896965190" class="footer-list_item--link">
                                        <i class="fas fa-phone-alt"></i><?=$site_sdt_momo;?>
                                    </a>
                                </li>
                            </ul>
                            <ul class="footer-social list-unstyled mb-0 hstack gap-5px">
                                <li class="footer-social_item">
                                    <a href="<?=$facebook;?>" class="footer-social_item--link">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
                                <li class="footer-social_item">
                                    <a href="https://t.me/ktmitvn" class="footer-social_item--link">
                                        <i class="fab fa-telegram"></i>
                                    </a>
                                </li>
                                <li class="footer-social_item">
                                    <a href="gmail:checkscam.com@gmail.com" class="footer-social_item--link">
                                        <i class="fab fa-google"></i>
                                    </a>
                                </li>
                                <li class="footer-social_item">
                                    <a href="tel:<?=$site_sdt_momo;?>"
                                       class="footer-social_item--link">
                                        <i class="fab fa-viber"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom section-gap">
        <div class="container">
            <div class="row g-3 justify-content-center justify-content-lg-between">
                <div class="col-auto">
                    <div class="hstack align-items-center footer-information">
                        <div class="footer-logo">
                            <img src="<?=$site_logo;?>" class="img-fluid" alt="">
                        </div>
                        <div class="footer-copyright">© Software by <?=$config['tacgia'];?> | All Rights Reserved</div>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="hstack justify-content-end gap-20px footer-logos">
                        <a href="//www.dmca.com/Protection/Status.aspx?ID=568af2a9-5d9a-4726-a1a2-5aec9db99ae6" target="_blank" title="DMCA.com Protection Status" class="dmca-badge"> <img src="//images.dmca.com/Badges/dmca-badge-w150-5x1-01.png?ID=568af2a9-5d9a-4726-a1a2-5aec9db99ae6" alt="DMCA.com Protection Status"></a>
                    </div>   <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
                </div>
            </div>
        </div>
    </div>
</footer>
   <noscript  type="text/javascript" src="<?=$config['tacgia'];?>"></noscript>
<div class="social-button">
    <div class="social-button-content">
        <a href="<?=$site['linktele'];?>" target="_blank" class="call-icon" rel="nofollow">
            <i class="fab fa-telegram-plane" aria-hidden="true"></i>
            <div class="animated alo-circle"></div>
            <div class="animated alo-circle-fill  "></div>
        </a>
    </div>
</div> 
<style>
    .social-button{
      display: inline-grid;
        position: fixed;
        bottom: 45px;
        right: 45px;
        min-width: 45px;
        text-align: center;
        z-index: 99999;
    }
    .social-button-content{
      display: inline-grid;   
    }
    .social-button a {padding:8px 0;cursor: pointer;position: relative;}
    .social-button i{
      width: 40px;
        height: 40px;
        background: #43a1f3;
        color: #fff;
        border-radius: 100%;
        font-size: 20px;
        text-align: center;
        line-height: 1.9;
        position: relative;
        z-index: 999;
    }
    .social-button span{
      display: none;
    }
    .alo-circle {
        animation-iteration-count: infinite;
        animation-duration: 1s;
        animation-fill-mode: both;
        animation-name: zoomIn;
        width: 50px;
        height: 50px;
        top: 3px;
        right: -3px;
        position: absolute;
        background-color: transparent;
        -webkit-border-radius: 100%;
        -moz-border-radius: 100%;
        border-radius: 100%;
        border: 2px solid rgba(30, 30, 30, 0.4);
        opacity: .1;
        border-color: #0089B9;
        opacity: .5;
    }
    .alo-circle-fill {
      animation-iteration-count: infinite;
      animation-duration: 1s;
      animation-fill-mode: both;
      animation-name: pulse;
        width: 60px;
        height: 60px;
        top: -2px;
        right: -8px;
        position: absolute;
        -webkit-transition: all 0.2s ease-in-out;
        -moz-transition: all 0.2s ease-in-out;
        -ms-transition: all 0.2s ease-in-out;
        -o-transition: all 0.2s ease-in-out;
        transition: all 0.2s ease-in-out;
        -webkit-border-radius: 100%;
        -moz-border-radius: 100%;
        border-radius: 100%;
        border: 2px solid transparent;
        background-color: rgba(0, 175, 242, 0.5);
        opacity: .75;
    }
   
    @-webkit-keyframes "headerAnimation" {
        0% { margin-top: -70px; }
        100% { margin-top: 0; }
    }
    @keyframes "headerAnimation" {
        0% { margin-top: -70px; }
        100% { margin-top: 0; }
    }
    .social-button a span:before {
      content: "";
      width: 0;
      height: 0;
      border-style: solid;
      border-width: 10px 10px 10px 0;
      border-color: transparent rgb(103, 182, 52) transparent transparent;
      position: absolute;
      left: -10px;
      top: 10px;
    }
  </style>