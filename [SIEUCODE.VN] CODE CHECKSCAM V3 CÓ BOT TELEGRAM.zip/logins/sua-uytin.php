<?php include('head.php');?>
<?php include('nav.php');?>
<div class="main_content_iner overly_inner ">
    <div class="container-fluid p-0 ">
        <div class="row">
            <div class="col-12">
                <?php
if (isset($_GET['code'])) {
    $code = $_GET['code'];
}

$AADDCC = mysqli_query($ketnoi, "
    SELECT 
        cards.*, 
        dichvuuser.ten AS ten_dichvuuser, 
        nganhang.nganhang AS nganhang_nganhang,
        nganhang.stk AS stk_nganhang,
        nganhang.ctk AS ctk_nganhang
    FROM 
        cards 
    JOIN 
        dichvuuser 
    ON 
        cards.code = dichvuuser.code 
    JOIN 
        nganhang
    ON 
        cards.code = nganhang.code 
    WHERE 
        cards.code = '".$code."'
");
while ($row = mysqli_fetch_array($AADDCC)) {
    if (isset($_POST["btn_submit"])) {

       $new_code = random('QWERTYUIOPASDFGHJKLZXCVBNM1234567890','6');
       $nganhang_string = implode(',', $_POST['nganhang']);
       $ten_string = implode(',', $_POST['ten']);
        mysqli_query($ketnoi, "UPDATE `dichvuuser` SET
            `ten` = '".$ten_string."' WHERE `code` = '".$code."' ");
            
       mysqli_query($ketnoi, "UPDATE `nganhang` SET
            `stk`= '".$_POST['stk']."',
            `ctk`= '".$_POST['ctk']."',
            `nganhang` = '".$nganhang_string."' WHERE `code` = '".$code."' ");
        
        mysqli_query($ketnoi, "UPDATE `cards` SET
            `username` = '".$_POST['user']."',
            `sdt`= '".$_POST['sdt']."',
            `id_fb` = '".$_POST['idfb']."',
            `linkfb` = '".$_POST['linkfb']."',
            `xt` = '".$_POST['xt']."',
            `website` = '".$_POST['website']."',
            `mo_ta` = '".$_POST['note']."',
            `money` = '".$_POST['money']."',
            `avatar` = '".$_POST['avatar']."',
            `goi` = '".$_POST['goi']."' WHERE `code` = '".$code."' ");
        
        echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "";
                });
                </script>';
    }
?>
                <div class="page_title_box d-flex align-items-center justify-content-between">
                    <div class="page_title_left">
                        <h3 class="f_s_30 f_w_700 dark_text">Sửa GDV</h3>
                        <ol class="breadcrumb page_bradcam mb-0">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active"> <?=$row['username'];?></li>
                        </ol>
                    </div>
                    <a href="#" class="white_btn3">Print</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="white_card card_height_100 mb_30">
                    <div class="white_card_header">
                        <div class="box_header m-0">
                            <div class="main-title">
                                <h3 class="m-0">TẠO HỒ SƠ</h3>
                            </div>
                        </div>
                    </div>
                    <div class="white_card_body">
                        <div class="card-body">
                            <form method="post">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="title">Họ Và Tên</label>
                                        <input type="text" class="form-control" name="user" value="<?=$row['username'];?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="avatar">IMAGE AV</label>
                                        <input type="text" name="avatar" class="form-control" value="<?=$row['avatar'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="anhbia">Ảnh Bìa <code>Có Thể Bỏ Trống</code></label>
                                        <input type="text" class="form-control" name="anhbia" placeholder="https://i.imgur.com/JhJ2aRL.jpg">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="sdt">SĐT</label>
                                       <input type="text" name="sdt" class="form-control" value="<?=$row['sdt'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="idfb">ID FB </label>
                                        <input type="text" name="idfb" class="form-control" value="<?=$row['id_fb'];?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="linkfb">Link FB</label>
                                        <input type="text" name="linkfb" class="form-control" value="<?=$row['linkfb'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="web">Website</label>
                                        <input type="text" name="website" class="form-control" value="<?=$row['website'];?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="money">Số Tiền Bảo Hiểm</label>
                                        <input type="text" name="money" class="form-control" value="<?=$row['money'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class=" col-md-6">
                                        <label class="form-label" for="inputState">XT Giấy Tờ</label>
                                        <select name="xt" class="form-select">
                                            <option value="0" <?= ($row['xt'] == '0') ? 'selected' : ''; ?>>Chưa xác minh</option>
                                            <option value="1" <?= ($row['xt'] == '1') ? 'selected' : ''; ?>>Đã xác minh</option>
                                        </select>
                                    </div>
                                    <div class=" col-md-6">
                                        <label class="form-label" for="inputState">Gói</label>
                                        <select name="goi" class="form-select">
                                            <option value="0" <?= ($row['goi'] == '0') ? 'selected' : ''; ?>>Gói Đồng</option>
                                            <option value="1" <?= ($row['goi'] == '1') ? 'selected' : ''; ?>>Gói Bạc</option>
                                            <option value="2" <?= ($row['goi'] == '2') ? 'selected' : ''; ?>>Gói Vàng</option>
                                            <option value="3" <?= ($row['goi'] == '3') ? 'selected' : ''; ?>>Gói Kim Cương</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Dịch Vụ</label>
                                        <select class="form-control select2" name="ten[]" multiple="multiple">
        <?php
                                        $atm = $row['ten_dichvuuser'];
                                        $delimiters = array(",");
                                        $atm = str_replace($delimiters, $delimiters[0], $atm);
                                        $arrKeyword= explode($delimiters[0], $atm);
                                        foreach ($arrKeyword as $key)
                                        {
                                           echo '<option value="'.$key.'" selected>'.$key.'</option>';
                                        }
                                        ?>
         
        <?php
        $result_category = mysqli_query($ketnoi, "SELECT * FROM `category`");
        while ($row_category = mysqli_fetch_array($result_category)) {
            ?>
            <option value="<?= $row_category['ten']; ?>"><?= $row_category['ten']; ?></option>
            <?php
        }
        ?>
    </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">MÔ TẢ:</label>
                                        <textarea name="note" id="mySummernote"><?=$row['mo_ta'];?></textarea>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Ngân Hàng( <a target="_blank"><b><a href="huongdan.php" style="text-decoration: none">Hướng Dẫn Thêm Ngân Hàng </a></b></a> )</label>
                                            <select name="nganhang[]" class="form-control select2" multiple="multiple" data-placeholder="Chọn danh mục" style="width: 100%;">
                                                <?php
                                        $atm = $row['nganhang_nganhang'];
                                        $delimiters = array(",");
                                        $atm = str_replace($delimiters, $delimiters[0], $atm);
                                        $arrKeyword= explode($delimiters[0], $atm);
                                        foreach ($arrKeyword as $key)
                                        {
                                           echo '<option value="'.$key.'" selected>'.$key.'</option>';
                                        }
                                        ?>
                                                <option value="VietinBank">VietinBank</option>
                                                <option value="MOMO">MoMo</option>
                                                <option value="KienLongBank">KienLongBank</option>
                                                <option value="Vietcombank">Vietcombank</option>
                                                <option value="BIDV">BIDV</option>
                                                <option value="OCB">OCB</option>
                                                <option value="MBBank">MBBank</option>
                                                <option value="Techcombank">Techcombank</option>
                                                <option value="ACB">ACB</option>
                                                <option value="VPBank">VPBank</option>
                                                <option value="TPBank">TPBank</option>
                                                <option value="Sacombank">Sacombank</option>
                                                <option value="HDBank">HDBank</option>
                                                <option value="SCB">SCB</option>
                                                <option value="VIB">VIB</option>
                                                <option value="SHB">SHB</option>
                                                <option value="Eximbank">Eximbank</option>
                                                <option value="MSB">MSB</option>
                                                <option value="CAKE">CAKE</option>
                                                <option value="ViettelMoney">ViettelMoney</option>
                                                <option value="Agribank">Agribank</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="web">STK <code>Mỗi Số Tài Khoản Tách Nhau Bởi Dấu (,)</code></label>
                                            <input type="text" class="form-control" name="stk" value="<?=$row['stk_nganhang'];?>">
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="money">Chủ Tài Khoản <code>Mỗi Chủ Tài Khoản Tách Nhau Bởi Dấu (,)</code></label>
                                            <input type="text" class="form-control" name="ctk" value="<?=$row['ctk_nganhang'];?>">
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" name="btn_submit" class="btn btn-primary">Cập Nhật</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
(function($) {
  // Wait for the document to be ready
  $(document).ready(function() {
    // Initialize Select2 after the document is ready
    $('.select2').select2();
  });
})(jQuery);
</script>
<script>
$(document).ready(function() {
  $('#mySummernote').summernote();
});
</script>
<?php }?>
<?php include('foot.php');?>
