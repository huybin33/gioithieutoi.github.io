<?php include('head.php');?>
<?php include('nav.php');?>
<?php
if (isset($_GET['delete'])) 
{
    $delete = $_GET['delete'];

    $create = mysqli_query($ketnoi,"DELETE FROM `category` WHERE `id` = '".$delete."' ");

    if ($create)
    {
      echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "chuyen-muc.php";
                                });
                                </script>'; 
    }
    else
    {
      echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "chuyen-muc.php";
                                });
                                </script>'; 
    }
}
?>

<?php
if (isset($_POST["submit"])) {
  $ten = $_POST["title"];
  $code = xoadau($ten);
  $create = mysqli_query($ketnoi,"INSERT INTO `category` SET 
  `ten` = '$ten',
  `image` = '".$_POST['image']."',
   `code` = '".$code."'  ");

  if($create)
  {
    echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Thêm Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "chuyen-muc.php";
                                });
                                </script>';
  }
  else
  {
    echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "chuyen-muc.php";
                                });
                                </script>'; 
  }
}

?>
<div class="main_content_iner ">
<div class="container-fluid p-0">
<div class="row justify-content-center">
<div class="col-lg-12">
<div class="white_card card_height_100 mb_30">
<div class="white_card_header">
<div class="box_header m-0">
<div class="main-title">
<h3 class="m-0">Dịch Vụ</h3>
</div>
</div>
</div>
<div class="white_card_body">
<div class="QA_section">
<div class="white_box_tittle list_header">
<h4>Danh Sách Dịch Vụ</h4>
<div class="box_right d-flex lms_block">
<div class="add_button ms-2">
<a type="button" data-bs-toggle="modal" data-bs-target="#addcategory" class="btn_1">Thêm</a>
</div>
</div>
</div>
<div class="QA_table mb_30">

<table class="table lms_table_active ">
<thead>
<tr>
<th scope="col">STT</th>    
<th scope="col">Thể Loại</th>
<th scope="col">Image DV</th>
<th scope="col">Status</th>
<th scope="col">Thao Tác</th>
</tr>
</thead>
<tbody>
    <?php
$result = mysqli_query($ketnoi,"SELECT * FROM `category` ORDER BY id desc ");
while($row = mysqli_fetch_assoc($result))
{
?>
      
<tr>
<th scope="row"> <a href="#" class="question_content"><?=$row['id'];?></a></th>
<td><?=$row['ten'];?></td>
<td><img src="<?=$row['image'];?>" alt="pic" height="80px"></td>
<td><a href="#" class="status_btn">Active</a></td>
<td>
<div class="action_btns d-flex">
<a href="chuyen-muc.php?delete=<?=$row['id'];?>" class="action_btn"> <i class="fas fa-trash"></i> </a>
</div>
</td>
</tr>
 <?php }?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- Modal -->
<div class="modal fade" id="addcategory" tabindex="-1" aria-labelledby="addcategory" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addcategory">Tạo Dịch Vụ</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form role="form" action="" method="post">
             <div class="form-group">
                <label for="exampleInputEmail1">TÊN DỊCH VỤ:</label>
                <input type="text" class="form-control" name="title" placeholder="Ví dụ: website, clone, xu">
            </div>
                    
            <div class="form-group">
                <label for="exampleInputEmail1">ẢNH DỊCH VỤ:</label>
                <input type="text" class="form-control" name="image" placeholder="Ví dụ: website, clone, xu">
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                <button type="submit" name="submit" class="btn btn-primary">Thêm</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function() {
    // Lắng nghe sự kiện hiển thị modal
    $('#addcategory').on('shown.bs.modal', function () {
        console.log('Modal hiển thị');
    });
});
</script>

</div>
</div>
</div>
<?php include('foot.php');?>
</body>