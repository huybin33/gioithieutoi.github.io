<?php include('head.php');?>
<?php include('nav.php');?>

<div class="main_content_iner ">
    <div class="container-fluid p-0">
      <?php
if (isset($_GET['delete'])) {
    $delete = $_GET['delete'];
   $img = mysqli_query($ketnoi,"SELECT * FROM `bangchung` WHERE `code` = '$delete' ORDER BY id desc");
    while($bc = mysqli_fetch_assoc($img)) {
    $patch ="..".$bc['image'];
    unlink($patch);
    }
    $create = mysqli_query($ketnoi,"DELETE FROM `ticket` WHERE `code` = '".$delete."'");
    $a = mysqli_query($ketnoi,"DELETE FROM `bangchung` WHERE `code` = '".$delete."'");
    if ($create) {
      echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Duyệt Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ho-tro.php";
                });
                </script>'; 
    } else {
      echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ho-tro.php";
                });
                </script>'; 
    }
}
        if (isset($_GET['scam'])) {
            $create = mysqli_query($ketnoi,"UPDATE `ticket` SET 
                `status` = 'scam' WHERE `id` = '".$_GET['scam']."' ");
            if ($create) {
                echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Duyệt Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ho-tro.php";
                });
                </script>'; 
            } else {
                echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ho-tro.php";
                });
                </script>'; 
            }
        }
        ?>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="white_card card_height_100 mb_30">
                    <div class="white_card_header">
                        <div class="box_header m-0">
                            <div class="main-title">
                                <h3 class="m-0">Đơn Tố Cáo</h3>
                            </div>
                        </div>
                    </div>
                    <div class="white_card_body">
                        <div class="QA_section">
                            <div class="white_box_tittle list_header">
                                <h4>Danh Sách Đơn Tố Cáo</h4>
                                <div class="box_right d-flex lms_block">
                                    <div class="serach_field_2">
                                        <div class="search_inner">
                                            <form Active="#">
                                                <div class="search_field">
                                                    <input type="text" placeholder="Search content here...">
                                                </div>
                                                <button type="submit"> <i class="ti-search"></i> </button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="add_button ms-2">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#addcategory" class="btn_1">Add New</a>
                                    </div>
                                </div>
                            </div>
                            <div class="QA_table mb_30">
                                <table class="table lms_table_active ">
                                    <thead>
                                        <tr>
                                            <th scope="col">STT</th>    
                                            <th scope="col">TYPE</th>
                                            <th scope="col">Tên</th>
                                            <th scope="col">Số Tiền</th>
                                            <th scope="col">STK</th>
                                            <th scope="col">LÝ DO</th>
                                            <th scope="col">DANH MỤC</th>
                                            <th scope="col">Image</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Thao Tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        $result = mysqli_query($ketnoi,"SELECT * FROM `ticket` ORDER BY id desc limit 0, 100000");
                                        while($row = mysqli_fetch_assoc($result)) {
                                        ?>
                                        <tr>
                                            <th scope="row"><a href="#" class="question_content"><?=$i++; ?></a></th>
                                            <td><?=$row['type'];?></td>
                                            <td><?=$row['username'];?></td>
                                            <td><?= number_format($row['sotien'], 0, ',', '.') ?>  VND</td>
                                            <td><?=$row['stk'];?></td>
                                            <td><?=$row['ly_do'];?></td>
                                            <td><?=$row['danhmuc'];?></td>
                                            <td>
                                                <?php foreach(mysqli_query($ketnoi,"SELECT * FROM `bangchung` WHERE `code` = '".$row['code']."'") as $img){ ?>
                                                <a href="<?=$img['image'];?>" target="_blank"><Button class="mb-2 bg-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">Xem</Button></a>
                                                <?php } ?>
                                            </td>
                                            <td>
                                                <?php
                                                if ($row['status'] == 'xuly') {
                                                    echo '<span class="mb-2 bg-danger ps-3 pe-3 pt-2 pb-2 rounded d-inline-block ">Chờ Duyệt</span>';
                                                } else if ($row['status'] == 'scam') {
                                                    echo '<span class="mb-2 bg-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block">Đã Duyệt</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <div class="action_btns d-flex">
                                                    <a href="ho-tro.php?scam=<?=$row['id'];?>" class="action_btn mr_10"> <i class="fa fa-check"></i> </a>
                                                    <a href="ho-tro.php?delete=<?=$row['code'];?>" class="action_btn"> <i class="fas fa-trash"></i> </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('foot.php');?>
