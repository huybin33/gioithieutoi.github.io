<?php include('head.php');?>
<?php include('nav.php');?>
<?php
if (isset($_GET['xoa'])) {
    $delete = $_GET['xoa'];

    $create = mysqli_query($ketnoi,"DELETE FROM `usersctv` WHERE `id` = '".$delete."' ");

    if ($create) {
      echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Xóa Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ctv.php";
                });
                </script>'; 
    } else {
      echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ctv.php";
                });
                </script>'; 
    }
}
?>
<div class="main_content_iner overly_inner">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-12">
                <div class="page_title_box d-flex align-items-center justify-content-between">
                    <div class="page_title_left">
                        <h3 class="f_s_30 f_w_700 dark_text">Tạo Tài Khoản CTV</h3>
                        <ol class="breadcrumb page_bradcam mb-0">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">Tạo Tài Khoản CTV</li>
                        </ol>
                    </div>
                    <a href="#" class="white_btn3">Print</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="white_card card_height_100 mb_30">
                    <div class="white_card_header">
                        <div class="box_header m-0">
                            <div class="main-title">
                                <h3 class="m-0">TẠO Tài Khoản CTV</h3>
                            </div>
                        </div>
                    </div>
                    <div class="white_card_body">
                        <div class="card-body">
                            <form method="post">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="username">Tài Khoản</label>
                                        <input type="text" class="form-control" name="username" placeholder="Nhập Tài Khoản">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="password">Mật Khẩu</label>
                                        <input type="text" class="form-control" name="password" placeholder="Nhập Mật Khẩu">
                                    </div>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Thêm Tài Khoản CTV</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="white_card_body">
                    <div class="QA_section">
                        <div class="white_box_tittle list_header">
                            <h4>Danh Sách Tài Khoản CTV</h4>
                            <div class="box_right d-flex lms_block">
                            </div>
                        </div>
                        <div class="QA_table mb_30">
                            <table class="table lms_table_active ">
                                <thead>
                                    <tr>
                                        <th scope="col">STT</th>    
                                        <th scope="col">Tên Tài Khoản</th>
                                        <th scope="col">Mật Khẩu</th>
                                        <th scope="col">Thao Tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
$i = 1;
$result = mysqli_query($ketnoi,"SELECT * FROM `usersctv` ORDER BY id desc limit 0, 100000");
while($row = mysqli_fetch_assoc($result))
{

?>
                                    <tr>
                                        <th scope="row"> <a href="#" class="question_content">1</a></th>
                                        <td><?=$row['username'];?></td>
                                        <td><?=$row['password'];?></td>
                                        <td>
                                            <div class="action_btns d-flex">
                                                
                                                <a href="ctv.php?xoa=<?=$row['id'];?>" class="action_btn"> <i class="fas fa-trash"></i> </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php }?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    if (isset($_POST["submit"]) && isset($_SESSION['admin']))
    {
      $create = mysqli_query($ketnoi,"INSERT INTO `usersctv` SET
        `username` = '".$_POST['username']."',
        `password` = '".$_POST['password']."' ");
      if ($create)
      {
        echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Thêm Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ctv.php";
                });
                </script>'; 
        die;
      }
      else
      {
        echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "ctv.php";
                });
                </script>'; 
        die;
      }
    }

?>
<?php include('foot.php');?>
