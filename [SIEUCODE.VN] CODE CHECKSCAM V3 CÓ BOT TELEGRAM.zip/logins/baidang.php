<?php include('head.php');?>
<?php include('nav.php');?>
<?php
    if (isset($_POST["submit"]) && isset($_SESSION['admin']))
    {
      $title = $_POST["title"];
      $data = xoadau($title);
      $create = mysqli_query($ketnoi,"INSERT INTO `tintuc` SET
        `title` = '$title',
        `anh` = '".$_POST['anh']."',
        `note` = '".$_POST['note']."',
        `data` = '".$data."'  ");
      if ($create)
      {
        echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
        die;
      }
      else
      {
        echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
        die;
      }
    }

?>
<?php
if (isset($_GET['xoa'])) {
    $delete = $_GET['xoa'];

    $create = mysqli_query($ketnoi,"DELETE FROM `tintuc` WHERE `id` = '".$delete."' ");

    if ($create) {
      echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
    } else {
      echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
    }
}
?>

<?php
    if (isset($_GET['duyet'])) {
          $create = mysqli_query($ketnoi,"UPDATE `tintuc` SET 
            `status` = 'hoantat' WHERE `id` = '".$_GET['duyet']."' ");
          if ($create) {
            echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
          } else {
            echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
          }
    }
    
    
    if (isset($_GET['xuly'])) {
          $create = mysqli_query($ketnoi,"UPDATE `tintuc` SET 
            `status` = 'xuly' WHERE `id` = '".$_GET['xuly']."' ");
          if ($create) {
            echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
          } else {
            echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "baidang.php";
                                });
                                </script>'; 
          }
    }
?>
<div class="main_content_iner ">
<div class="container-fluid p-0">
<div class="row justify-content-center">
<div class="col-lg-12">
<div class="white_card card_height_100 mb_30">
<div class="white_card_header">
<div class="box_header m-0">
<div class="main-title">
<h3 class="m-0">Bài Viết</h3>
</div>
</div>
</div>
<div class="white_card_body">
<div class="QA_section">
<div class="white_box_tittle list_header">
<h4>Danh Sách Bài Viết</h4>
<div class="box_right d-flex lms_block">
<div class="add_button ms-2">
<a type="button" data-bs-toggle="modal" data-bs-target="#addcategory" class="btn_1">Thêm Mới</a>
</div>
</div>
</div>
<div class="QA_table mb_30">

<table class="table lms_table_active ">
<thead>
<tr>
<th scope="col">STT</th>    
<th scope="col">Tiêu Đề</th>
<th scope="col">Nội Dung</th>
<th scope="col">Ảnh</th>
<th scope="col">Status</th>
<th scope="col">Thao Tác</th>
</tr>
</thead>
<tbody>
    <?php
$i = 1;
$result = mysqli_query($ketnoi,"SELECT * FROM `tintuc` ORDER BY id desc limit 0, 100000");
while($row = mysqli_fetch_assoc($result))
{

?>
<tr>
<th scope="row"> <a href="#" class="question_content"><?=$i++; ?></a></th>
<td><?=$row['title'];?></td>
<td><?=$row['note'];?></td>
<td><img src="<?=$row['anh'];?>" alt="pic" height="80px"></td>
<td class="text-center">
                                                <?php if($row['status'] == 'hoantat') { ?>
                                                    <a href="?xuly=<?=$row['id'];?>">
                                                        <span class="mb-2 bg-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block" aria-hidden="true"> ON</span>
                                                    </a>
                                                <?php } else { ?>
                                                    <a href="?duyet=<?=$row['id'];?>">
                                                        <span class="mb-2 bg-danger ps-3 pe-3 pt-2 pb-2 rounded d-inline-block" aria-hidden="true"> OFF</span>
                                                    </a>
                                                <?php } ?>
                                            </td>
<td>
<div class="action_btns d-flex">
<a href="?xoa=<?=$row['id'];?>" class="action_btn"> <i class="fas fa-trash"></i> </a>
</div>
</td>
</tr>
<?php }?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- Modal -->
<div class="modal fade" id="addcategory" tabindex="-1" aria-labelledby="addcategory" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addcategory">Tạo Bài Viết</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Form or content for adding new category goes here -->
        <form role="form" action="" method="post">
        <div class="row mb-3">
<div class="col-md-6">
<label class="form-label" for="title">Tiêu Đề </label>
<input type="text" class="form-control" name="title" placeholder="Nhập Tiêu Đề">
</div>
<div class="col-md-6">
<label class="form-label" for="anh">Link Ảnh</label>
<input type="text" class="form-control" name="anh" placeholder="Nhập Link Ảnh">
</div>
</div>
<div class="col-md-12">
<div class="form-group">
                        <label for="exampleInputEmail1">MÔ TẢ:</label> <font color="red">(Nếu Đăng Kèm Ảnh Chỉ Được Up Link)</font>
                        <textarea name="note" id="mySummernote"></textarea>

                    </div>
          <!-- Other form fields go here -->
        
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
        <button type="submit" name="submit" class="btn btn-primary">Thêm</button>
      </div>
      </form>
    </div>
  </div>
</div>
<script>
$(document).ready(function() {
    // Lắng nghe sự kiện hiển thị modal
    $('#addcategory').on('shown.bs.modal', function () {
        console.log('Modal hiển thị');
    });
});
</script>
<script>
$(document).ready(function() {
  $('#mySummernote').summernote();
});
</script>
</div>
</div>
</div>
<?php include('foot.php');?>
</body>