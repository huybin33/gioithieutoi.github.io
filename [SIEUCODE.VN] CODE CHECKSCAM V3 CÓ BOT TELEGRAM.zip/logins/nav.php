
<style>
    .navbar {
    padding: 10px;
    font-size: 14px;
}

.logo img {
    width: 100px; 
    height: auto; 
}

.navbar a {
    padding: 5px 10px; 
}
.sidebar_close_icon {
    font-size: 20px;
}
<?php
if(isset($_POST['luupass'])) {
$create = $ketnoi->query("UPDATE `users` SET
    `username` = '".$_POST['user']."',
    `password` = '".$_POST['pass']."' ");

if ($create) {
echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "";
                                });
                                </script>'; 
} else {
echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "";
                                });
                                </script>'; 
}


}
?>
</style>
<nav class="sidebar dark_sidebar active_sidebar">
<div class="logo d-flex justify-content-between">
<a class="large_logo" href="/">
    <img src="https://i.imgur.com/nMxPgiz.png" alt="logo" width="auto" height="auto">
</a>
<a class="small_logo" href="/">
    <img src="https://i.imgur.com/nMxPgiz.png" alt="logo" width="108" height="34">
</a>
<div class="sidebar_close_icon d-lg-none">
<i class="ti-close"></i>
</div>
</div>
<ul id="sidebar_menu">
<li>
<a href="index.php" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/dashboard.svg" alt>
</div>
<div class="nav_title">
<span>Trang Chủ</span>
</div>
</a>
</li>
<li>
<h4 class="menu-text"><span>Đơn Tố Cáo</span> <i class="fas fa-ellipsis-h"></i> </h4>
<li class>
<a href="ho-tro.php" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/8.svg" alt>
</div>
<div class="nav_title">
<span>Xử Lý Đơn Tố Cáo</span> 
</div>
</a>
</li>
<li>
<h4 class="menu-text"><span>Giao Dịch Viên</span> <i class="fas fa-ellipsis-h"></i> </h4>
<li class>
<a class="has-arrow" href="#" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/5.svg" alt>
</div>
<div class="nav_title">
<span>Hồ Sơ Uy Tín </span>
</div>
</a>
<ul>
<li><a href="uytin.php">Số GDV Hiện Có</a></li>
<li><a href="gdv.php">Thêm Hồ Sơ Uy Tín</a></li>
</ul>
</li>
<li class>
<a class="has-arrow" href="#" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/16.svg" alt>
</div>
<div class="nav_title">
<span>Dịch Vụ Khác</span>
</div>
</a>
<ul>
<li><a href="chuyen-muc.php">Dịch Vụ [ MENU ]</a></li>
<li><a href="baidang.php">Thêm Bài Viết</a></li>
</ul>
</li>
<h4 class="menu-text"><span>Quản Lý</span> <i class="fas fa-ellipsis-h"></i> </h4>
<li class>
<a href="ctv.php" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/6.svg" alt>
</div>
<div class="nav_title">
<span>Thêm Tài Khoản CTV</span>
</div>
</a>
</li>
<li class>
<a class="has-arrow" href="#" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/4.svg" alt>
</div>
<div class="nav_title">
<span>Cài Đặt</span>
</div>
</a>
<ul>
<li><a href="cai-dat.php">Cài Đặt Website</a></li>
<li><a href="editdkgt.php">Chỉnh Sửa DK & GT</a></li>
</ul>
</li>
<li class>
<a href="login.php" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/5.svg" alt>
</div>
<div class="nav_title">
<span>Đăng Xuất</span>
</div>
</a>
</li>
</nav>
<section class="main_content dashboard_part large_header_bg">

<div class="container-fluid g-0">
<div class="row">
<div class="col-lg-12 p-0 ">
<div class="header_iner d-flex justify-content-between align-items-center">
<div class="sidebar_icon d-lg-none">
<i class="ti-menu"></i>
</div>
<label class="form-label switch_toggle d-none d-lg-block" for="checkbox">
<input type="checkbox" id="checkbox">
<div class="slider round open_miniSide"></div>
</label>
<div class="header_right d-flex justify-content-between align-items-center">
<div class="header_notification_warp d-flex align-items-center">
<li>
<div class="serach_button">
<i class="ti-search"></i>
<div class="serach_field-area d-flex align-items-center">
<div class="search_inner">
<form action="#">
<div class="search_field">
<input type="text" placeholder="Search here...">
</div>
<button class="close_search"> <i class="ti-search"></i> </button>
</form>
</div>
<span class="f_s_14 f_w_400 ml_25 white_text text_white">Apps</span>
</div>
</div>
</li>
<li>
<a class="bell_notification_clicker" href="#"> <img src="img/icon/bell.svg" alt>
<span>2</span>
</a>

<div class="Menu_NOtification_Wrap">
<div class="notification_Header">
<h4>Thông Báo</h4>
</div>
<div class="Notification_body">

<div class="single_notify d-flex align-items-center">
<div class="notify_thumb">
<a href="#"><img src="img/staf/2.png" alt></a>
</div>
<div class="notify_content">
<a href="#"><h5>Nguyễn Duy Khánh </h5></a>
<p>Cảm Ơn Bạn Đã Sử Dụng Code Của Chúng Tôi</p>
</div>
</div>
</div>
<div class="nofity_footer">
<div class="submit_button text-center pt_20">
<a href="#" class="btn_1">See More</a>
</div>
</div>
</div>

</li>
<li>
<a class="CHATBOX_open" href="#"> <img src="img/icon/msg.svg" alt> <span>2</span> </a>
</li>
</div>
<div class="profile_info">
<img src="img/client_img.png" alt="#">
<div class="profile_info_iner">
<div class="profile_author_name">
<p>Hello QTV </p>
<h5>Quản Trị Viên</h5>
</div>
<div class="profile_info_details">
<a type="button" data-bs-toggle="modal" data-bs-target="#addcategory">Đổi Mật Khẩu </a>
<a href="login.php">Log Out </a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- Modal -->
<div class="modal fade" id="addcategory" tabindex="-1" aria-labelledby="addcategory" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
          <?php
                  $result = mysqli_query($ketnoi,"SELECT * FROM `users` ");
                  while ($user = mysqli_fetch_array($result) ) { ?>
                 
        <h5 class="modal-title" id="addcategory">Tại Khoản MK Admin</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form role="form" action="" method="post">
             <div class="form-group">
                <label for="exampleInputEmail1">Tài Khoản</label>
                <input type="text" class="form-control" name="user" value="<?=$user['username'];?>">
            </div>
                    
            <div class="form-group">
                <label for="exampleInputEmail1">Mật Khẩu</label>
                <input type="text" class="form-control" name="pass"  value="<?=$user['password'];?>">
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                <button type="submit" name="luupass" class="btn btn-primary">Cập Nhật</button>
            </div>
        </form>
      </div>
       <?php } ?>
    </div>
  </div>
</div>