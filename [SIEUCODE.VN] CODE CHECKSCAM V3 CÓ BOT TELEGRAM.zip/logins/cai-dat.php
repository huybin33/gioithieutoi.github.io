<?php include('head.php');?>
<?php include('nav.php');?>
<?php
    if (isset($_POST["submit"]) && isset($_SESSION['admin']))
    {
            $mau=$_POST['themes'];

      $create = $ketnoi->query("UPDATE `setting` SET
        `site_logo` = '".$_POST['site_logo']."',
        `banner` = '".$_POST['banner']."',
        `linktele` = '".$_POST['linktele']."',
        `facebook` = '".$_POST['facebook']."',
        `sdt_admin` = '".$_POST['site_sdt_momo']."',
        `color` = '".$_POST['themes']."',
        `site_tenweb` = '".$_POST['site_tenweb']."',
        `modal` = '".$_POST['modal']."',
        `site_mota` = '".$_POST['site_mota']."' ");

      if ($create)
      {
        echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "cai-dat.php";
                });
                </script>'; 
        
      }
      else
      {
        echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "cai-dat.php";
                });
                </script>'; 
       
      }
    }

?>
<div class="main_content_iner overly_inner ">
<div class="container-fluid p-0 ">

<div class="row">
<div class="col-12">
<div class="page_title_box d-flex align-items-center justify-content-between">
<div class="page_title_left">
<h3 class="f_s_30 f_w_700 dark_text">Trang Quản Lý</h3>
<ol class="breadcrumb page_bradcam mb-0">
<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
<li class="breadcrumb-item active">Cài Đặt Website</li>
</ol>
</div>
</div>
</div>
</div>
<div class="row ">
<div class="col-lg-12">
<div class="white_card card_height_100 mb_30">
<div class="white_card_header">
<div class="box_header m-0">
<div class="main-title">
<h3 class="m-0">Quản Lý</h3>
</div>
</div>
</div>
<div class="white_card_body">
<div class="card-body">
<form  method="post">
<div class="row mb-3">
<div class="col-md-6">
<label class="form-label" for="site_logo">Ảnh Logo Web</label>
<input type="text" class="form-control" name="site_logo" placeholder="Nhập Logo Website" value="<?=$site_logo;?>">
</div>
<div class="col-md-6">
<label class="form-label" for="banner">Ảnh Banner Web</label>
<input type="text" class="form-control" name="banner" placeholder="https://i.imgur.com/JhJ2aRL.jpg" value="<?=$site['banner'];?>">
</div>
</div>
<div class="row mb-3">
<div class="col-md-6">
<label class="form-label" for="site_tenweb">TÊN WEB</label>
<input type="text" class="form-control" name="site_tenweb" placeholder="DichVuRight.Com" value="<?=$site_tenweb;?>">
</div>
<div class="col-md-6">
<label class="form-label" for="site_sdt_momo">SDT Admin</label>
<input type="number" class="form-control" name="site_sdt_momo" placeholder="Nhập Số Điện Thoại" value="<?=$site_sdt_momo;?>">
</div>
</div>
<div class="row mb-3">
<div class="col-md-6">
<label class="form-label" for="facebook">Link Fb Admin </label>
<input type="text" class="form-control" name="facebook" placeholder="https://www.facebook.com/dichvuright" value="<?=$site['facebook'];?>">
</div>
<div class="col-md-6">
<label class="form-label" for="linktele">Link Box Tele</label>
<input type="text" class="form-control" name="linktele" placeholder="https://t.me/dichvuright" value="<?=$site['linktele'];?>">
</div>
</div>
<div class="row mb-3">
<div class="col-md-12">
<label class="form-label" for="site_mota">Mô Tả WebSite</label>
<input type="text" class="form-control" name="site_mota" placeholder="Hệ Thống Chống Scam Uy Tín" value="<?=$site_mota;?>">
</div>
</div>
<div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Màu Web</label>
                                <input type="color" class="form-control" placeholder="Màu Web"
                                    name="themes" value="<?=$site_theme;?>">
                            </div>
                        </div>
<div class="col-md-12">
<div class="form-group">
                        <label for="exampleInputEmail1">Thông Báo:</label>
                        <textarea name="modal" id="mySummernote"><?=$site['modal'];?></textarea>

                    </div>
</div>
</div>
<button type="submit" name="submit" class="btn btn-primary">Cập Nhật</button>
</form>
</div>
</div>
</div>
</div>
</div>
</div> 
<script>
$(document).ready(function() {
  $('#mySummernote').summernote();
});
</script>
<?php include('foot.php');?>