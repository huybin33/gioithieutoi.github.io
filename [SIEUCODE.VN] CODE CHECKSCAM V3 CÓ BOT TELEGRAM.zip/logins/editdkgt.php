<?php include('head.php');?>
<?php include('nav.php');?>
<?php
    if (isset($_POST["submit"]) && isset($_SESSION['admin']))
    {
        
      $create = $ketnoi->query("UPDATE `setting` SET
        `site_dieukhoan` = '".$_POST['site_dieukhoan']."',
        `site_gioithieu` = '".$_POST['site_gioithieu']."' ");

      if ($create)
      {
        echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "editdkgt.php";
                });
                </script>'; 
        die;
      }
      else
      {
        echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "editdkgt.php";
                });
                </script>'; 
        die;
      }
    }

?>
<div class="main_content_iner overly_inner ">
<div class="container-fluid p-0 ">

<div class="row">
<div class="col-12">
<div class="page_title_box d-flex align-items-center justify-content-between">
<div class="page_title_left">
<h3 class="f_s_30 f_w_700 dark_text">Tạo Hồ Sơ Uy Tín</h3>
<ol class="breadcrumb page_bradcam mb-0">
<li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
<li class="breadcrumb-item active">Tạo Hồ Sơ Uy Tín</li>
</ol>
</div>
<a href="#" class="white_btn3">Print</a>
</div>
</div>
</div>
<div class="row ">
<div class="col-lg-12">
<div class="white_card card_height_100 mb_30">
<div class="white_card_header">
<div class="box_header m-0">
<div class="main-title">
<h3 class="m-0">Điều Khoản & Giới Thiệu</h3>
</div>
</div>
</div>
<div class="white_card_body">
<div class="card-body">
<form  method="post">   
<div class="col-md-12">
<div class="form-group">
                        <label for="exampleInputEmail1">Điều Khoản :</label>
                        <textarea name="site_dieukhoan" id="mySummernote1"><?=$site['site_dieukhoan'];?></textarea>

                    </div>
</div>
<div class="col-md-12">
<div class="form-group">
                        <label for="exampleInputEmail1">Giới Thiệu :</label>
                        <textarea name="site_gioithieu" id="mySummernote2"><?=$site['site_gioithieu'];?></textarea>

                    </div>
</div>
<button type="submit" name="submit" class="btn btn-primary">Lưu Ngay</button>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div> 
<script>
$(document).ready(function() {
  // Khởi tạo trình soạn thảo cho trình #mySummernote1
  $('#mySummernote1').summernote();
  
  // Khởi tạo trình soạn thảo cho trình #mySummernote2
  $('#mySummernote2').summernote();
});
</script>

<?php include('foot.php');?>