<?php include('head.php');?>
<?php include('nav.php');?>
<div class="main_content_iner overly_inner ">
    <div class="container-fluid p-0 ">
        <div class="row">
            <div class="col-12">
                <?php
                if (isset($_POST["submit"])) {
                    $ngay = date('d-m-Y');
                    $user = $_POST["title"];
                    $tenArray = $_POST["ten"];
                    $ten = implode(",", $tenArray);
                    $nganhangArray = $_POST["nganhang"];
                    $nganhang = implode(",", $nganhangArray);
                    $code = xoadau($user); 
                    if (isset($_POST['ten'])) {
                    }

                    $create_dichvuuser = mysqli_query($ketnoi, "INSERT INTO `dichvuuser` SET 
                        `ten` = '$ten',
                        `code` = '" . $code . "'  ");
                        
                    $create_nganhang = mysqli_query($ketnoi, "INSERT INTO `nganhang` SET 
                        `nganhang` = '$nganhang',
                        `stk` = '" . $_POST['stk'] . "',
                        `ctk` = '" . $_POST['ctk'] . "',
                        `ngay` = '$ngay',
                        `code` = '" . $code . "'  ");  
                    
                    $create_cards = mysqli_query($ketnoi, "INSERT INTO `cards` SET 
                        `username` = '$user',
                        `avatar` = '" . $_POST['avatar'] . "',
                        `mo_ta` = '" . $_POST['note'] . "',
                        `xt` = '" . $_POST['xt'] . "',
                        `anhbia` = '" . $_POST['anhbia'] . "',
                        `sdt` = '" . $_POST['sdt'] . "',
                        `id_fb` = '" . $_POST['idfb'] . "',
                        `linkfb` = '" . $_POST['linkfb'] . "',
                        `website` = '" . $_POST['website'] . "',
                        `money` = '" . $_POST['money'] . "',
                        `goi` = '" . $_POST['goi'] . "',
                        `code` = '" . $code . "'  ");
                    if ($create_cards && $create_dichvuuser && $create_nganhang) {
                        echo '<script type="text/javascript"> 
                                Swal.fire({
                                    icon: "success",
                                    title: "Tạo Thành Công ",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "gdv.php";
                                });
                                </script>';
                    } else {
                        echo '<script type="text/javascript">
                                Swal.fire({
                                    icon: "error",
                                    title: "Lỗi",
                                    text: "Lỗi Vui Lòng Xem Lại! ' . mysqli_error($ketnoi) . '",
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    window.location.href = "gdv.php";
                                });
                                </script>';
                    }
                }
                ?>
                <div class="page_title_box d-flex align-items-center justify-content-between">
                    <div class="page_title_left">
                        <h3 class="f_s_30 f_w_700 dark_text">Tạo Hồ Sơ Uy Tín</h3>
                        <ol class="breadcrumb page_bradcam mb-0">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">Tạo Hồ Sơ Uy Tín</li>
                        </ol>
                    </div>
                    <a href="#" class="white_btn3">Print</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="white_card card_height_100 mb_30">
                    <div class="white_card_header">
                        <div class="box_header m-0">
                            <div class="main-title">
                                <h3 class="m-0">TẠO HỒ SƠ</h3>
                            </div>
                        </div>
                    </div>
                    <div class="white_card_body">
                        <div class="card-body">
                            <form method="post">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="title">Họ Và Tên</label>
                                        <input type="text" class="form-control" name="title" placeholder="Nhập Họ Và Tên">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="avatar">IMAGE AV</label>
                                        <input type="text" class="form-control" name="avatar" placeholder="https://i.imgur.com/JhJ2aRL.jpg">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="anhbia">Ảnh Bìa <code>Có Thể Bỏ Trống</code></label>
                                        <input type="text" class="form-control" name="anhbia" placeholder="https://i.imgur.com/JhJ2aRL.jpg">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="sdt">SĐT</label>
                                        <input type="number" class="form-control" name="sdt" placeholder="Nhập Số Điện Thoại">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="idfb">ID FB </label>
                                        <input type="number" class="form-control" name="idfb" placeholder="Nhập ID FB">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="linkfb">Link FB</label>
                                        <input type="text" class="form-control" name="linkfb" placeholder="https://www.facebook.com/dichvuright">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label" for="web">Website</label>
                                        <input type="text" class="form-control" name="website" placeholder="DichVuRight.Com">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="money">Số Tiền Bảo Hiểm</label>
                                        <input type="number" class="form-control" name="money" placeholder="Nhập Số Tiền">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class=" col-md-6">
                                        <label class="form-label" for="inputState">XT Giấy Tờ</label>
                                        <select name="xt" class="form-select">
                                            <option value="0">Chưa xác minh</option>
                                            <option value="1">Đã xác minh</option>
                                        </select>
                                    </div>
                                    <div class=" col-md-6">
                                        <label class="form-label" for="inputState">Gói</label>
                                        <select name="goi" class="form-select">
                                            <option value="0">Gói Đồng</option>
                                            <option value="1">Gói Bạc</option>
                                            <option value="2">Gói Vàng</option>
                                            <option value="3">Gói Kim Cương</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Dịch Vụ</label>
                                        <select name="ten[]" class="form-control select2" multiple="multiple" data-placeholder="Chọn danh mục" style="width: 100%;">
                                            <?php
                                            $result = mysqli_query($ketnoi,"SELECT * FROM `category` ");
                                            while ($row1 = mysqli_fetch_array($result) ) { ?>
                                                <option value="<?=$row1['ten'];?>"><?=$row1['ten'];?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">MÔ TẢ:</label>
                                        <textarea name="note" id="mySummernote"></textarea>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Ngân Hàng( <a target="_blank"><b><a href="huongdan.php" style="text-decoration: none">Hướng Dẫn Thêm Ngân Hàng </a></b></a> )</label>
                                            <select name="nganhang[]" class="form-control select2" multiple="multiple" data-placeholder="Chọn danh mục" style="width: 100%;">
                                                <option value="VietinBank">VietinBank</option>
                                                <option value="MOMO">MoMo</option>
                                                <option value="KienLongBank">KienLongBank</option>
                                                <option value="Vietcombank">Vietcombank</option>
                                                <option value="BIDV">BIDV</option>
                                                <option value="OCB">OCB</option>
                                                <option value="MBBank">MBBank</option>
                                                <option value="Techcombank">Techcombank</option>
                                                <option value="ACB">ACB</option>
                                                <option value="VPBank">VPBank</option>
                                                <option value="TPBank">TPBank</option>
                                                <option value="Sacombank">Sacombank</option>
                                                <option value="HDBank">HDBank</option>
                                                <option value="SCB">SCB</option>
                                                <option value="VIB">VIB</option>
                                                <option value="SHB">SHB</option>
                                                <option value="Eximbank">Eximbank</option>
                                                <option value="MSB">MSB</option>
                                                <option value="CAKE">CAKE</option>
                                                <option value="ViettelMoney">ViettelMoney</option>
                                                <option value="Agribank">Agribank</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="web">STK <code>Mỗi Số Tài Khoản Tách Nhau Bởi Dấu (,)</code></label>
                                            <input type="text" class="form-control" name="stk" placeholder="Nhập Số Tài Khoản">
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="money">Chủ Tài Khoản <code>Mỗi Chủ Tài Khoản Tách Nhau Bởi Dấu (,)</code></label>
                                            <input type="text" class="form-control" name="ctk" placeholder="Nhập Chủ Tài Khoản">
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Tạo Hồ Sơ</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
(function($) {
  // Wait for the document to be ready
  $(document).ready(function() {
    // Initialize Select2 after the document is ready
    $('.select2').select2();
  });
})(jQuery);
</script>
<script>
$(document).ready(function() {
  $('#mySummernote').summernote();
});
</script>
<?php include('foot.php');?>
