<?php 
require_once('../ketnoi/config.php');
date_default_timezone_set("Asia/Ho_Chi_minh");
 $time = date("h:i:s");
 $site = $_SERVER['SERVER_NAME'];
 $ip = $_SERVER['REMOTE_ADDR'];  
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Trang Đăng Nhập</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" href="https://i.imgur.com/HCpkPFW.jpeg" type="image/png">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<style>
.logo {
    display: block;
    margin-left: auto;
    margin-right: auto;
    max-width: 100%;
    height: auto;
}
</style>
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="https://i.imgur.com/HCpkPFW.jpeg" alt="IMG">
				</div>
   <?php

if (isset($_POST["submit"]))
{
    $username = str_replace(array('<',"'",'>','?','/',"\\",'--','eval(','<php'),array('','','','','','','','',''),htmlspecialchars(addslashes(strip_tags($_POST['username']))));
    $password = str_replace(array('<',"'",'>','?','/',"\\",'--','eval(','<php'),array('','','','','','','','',''),htmlspecialchars(addslashes(strip_tags($_POST['password']))));
    if ($username == "" || $password =="") 
    {
        echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Không được để trống tên đăng nhập hoặc mật khẩu"
                });
            </script>';
    }
    else
    {
        $sql = "SELECT * FROM `users` WHERE `username` = '".$username."' AND `password` = '".$password."' AND `level` = 'duykhanh'  ";
        $query = mysqli_query($ketnoi,$sql);
        $num_rows = mysqli_num_rows($query);

        if ($num_rows == 0) {
            echo '<script type="text/javascript">
    Swal.fire({
        icon: "error",
        title: "Lỗi",
        text: "Thông tin đăng nhập không chính xác. Vui lòng thử lại!",
        showConfirmButton: false,
        timer: 2000
    }).then(() => {
        window.location.href = "login.php";
    });
</script>';
            die();
        } else {
         
            $_SESSION['admin'] = $username;
            echo '<script type="text/javascript">
                    Swal.fire({
                        icon: "success",
                        title: "Đăng nhập thành công",
                        showConfirmButton: false,
                        timer: 2000
                    }).then(() => {
                        window.location.href = "index.php";
                    });
                </script>';
        }
    }
}
?> 
				<form class="login100-form validate-form" method="POST">
                <img src="https://i.imgur.com/HCpkPFW.jpeg" class="logo" alt="Site Logo">
					<span class="login100-form-title">
					 ADMIN WEBSITE
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Nhập Tài Khoản">
						<input class="input100" type="text" name="username" placeholder="Tài Khoản" autofocus>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Nhập Mật Khẩu">
						<input class="input100" type="password" name="password" placeholder="Mật Khẩu">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button type="submit" name="submit" class="login100-form-btn">
							Login
						</button>
					</div>

					<div class="text-center p-t-12">
						<span class="txt1">
							Forgot
						</span>
						<a class="txt2" href="#">
							Username / Password?
						</a>
					</div>

					<div class="text-center p-t-136">
                    2024 © Copyright - Designed by
						<a class="txt2" href="https://touytin.io.vn">
							Touytin.io.vn
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>