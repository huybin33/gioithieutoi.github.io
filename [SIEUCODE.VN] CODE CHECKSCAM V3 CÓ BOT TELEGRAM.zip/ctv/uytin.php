<?php include('head.php');?>
<?php include('nav.php');?>

<div class="main_content_iner ">
    <div class="container-fluid p-0">
        <?php
        if (isset($_GET['delete'])) 
        {
            $delete = $_GET['delete'];
            $delete_cards = mysqli_query($ketnoi, "DELETE FROM cards WHERE code = '".$delete."'");
            $delete_dichvuuser = mysqli_query($ketnoi, "DELETE FROM dichvuuser WHERE code = '".$delete."'");
            $delete_nganhang = mysqli_query($ketnoi, "DELETE FROM nganhang WHERE code = '".$delete."'");

            if ($delete_cards && $delete_dichvuuser && $delete_nganhang)
            {
                echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Xóa Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "uytin.php";
                });
                </script>'; 
            }
            else
            {
                echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "uytin.php";
                });
                </script>'; 
            }
        }
        ?>
        <?php
        if (isset($_GET['duyet'])) {
            $create = mysqli_query($ketnoi,"UPDATE `cards` SET 
                `status` = null WHERE `id` = '".$_GET['duyet']."' ");
            if ($create) {
                echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Hoạt Động Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "uytin.php";
                });
                </script>'; 
            } else {
                echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "uytin.php";
                });
                </script>'; 
            }
        }
        ?>

        <?php
        if (isset($_GET['xuly'])) {
            $create = mysqli_query($ketnoi,"UPDATE `cards` SET 
                `status` = '0' WHERE `id` = '".$_GET['xuly']."' ");
            if ($create) {
                echo '<script type="text/javascript"> 
                Swal.fire({
                    icon: "success",
                    title: "Tạm Khóa Thành Công",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "uytin.php";
                });
                </script>'; 
            } else {
                echo '<script type="text/javascript">
                Swal.fire({
                    icon: "error",
                    title: "Lỗi",
                    text: "Lỗi Vui Lòng Xem Lại!",
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = "uytin.php";
                });
                </script>'; 
            }
        }
        ?>

        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="white_card card_height_100 mb_30">
                    <div class="white_card_header">
                        <div class="box_header m-0">
                            <div class="main-title">
                                <h3 class="m-0">Hồ Sơ Uy Tín</h3>
                            </div>
                        </div>
                    </div>
                    <div class="white_card_body">
                        <div class="QA_section">
                            <div class="white_box_tittle list_header">
                                <h4>Danh Sách GDV</h4>
                                <div class="box_right d-flex lms_block">
                                    <div class="serach_field_2">
                                        <div class="search_inner">
                                            <form Active="#">
                                                <div class="search_field">
                                                    <input type="text" placeholder="Search content here...">
                                                </div>
                                                <button type="submit"> <i class="ti-search"></i> </button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="add_button ms-2">
                                        <a href="gdv.php" class="btn_1">Thêm GDV</a>
                                    </div>
                                </div>
                            </div>
                            <div class="QA_table mb_30">
                                <table class="table lms_table_active ">
                                    <thead>
                                        <tr>
                                            <th scope="col">STT</th>    
                                            <th scope="col">image</th>
                                            <th scope="col">Code</th>
                                            <th scope="col">Tên GDV</th>
                                            <th scope="col">Số Tiền Cọc</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Thao Tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        $result = mysqli_query($ketnoi,"SELECT * FROM `cards` ORDER BY id desc ");
                                        while($row = mysqli_fetch_assoc($result))
                                        {
                                        ?>
                                        <tr>
                                            <th scope="row"><a href="#" class="question_content"><?=$i++; ?></a></th>
                                            <td><img src="<?=$row['avatar'];?>" alt="pic" height="80px"></td>
                                            <td><?=$row['code'];?></td>
                                            <td><?=$row['username'];?></td>
                                           <td><?= number_format(floatval($row['money']), 0, ',', '.') ?> VND</td>
                                            <td class="text-center">
                                                <?php if($row['status'] == null) { ?>
                                                    <a href="?xuly=<?=$row['id'];?>">
                                                        <span class="mb-2 bg-success ps-3 pe-3 pt-2 pb-2 rounded d-inline-block" aria-hidden="true"> ON</span>
                                                    </a>
                                                <?php } else { ?>
                                                    <a href="?duyet=<?=$row['id'];?>">
                                                        <span class="mb-2 bg-danger ps-3 pe-3 pt-2 pb-2 rounded d-inline-block" aria-hidden="true"> OFF</span>
                                                    </a>
                                                <?php } ?>
                                            </td>
                                            <td>
                                                <div class="action_btns d-flex">
                                                    <a href="sua-uytin.php?code=<?=$row['code'];?>" class="action_btn mr_10"> <i class="far fa-edit"></i> </a>
                                                    <a href="uytin.php?delete=<?=$row['code'];?>" class="action_btn"> <i class="fas fa-trash"></i> </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('foot.php');?>
