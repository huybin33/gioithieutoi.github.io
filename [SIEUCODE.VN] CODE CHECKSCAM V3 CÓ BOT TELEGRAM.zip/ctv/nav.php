<style>
    .navbar {
    padding: 10px; /* Thay đổi padding để làm cho thanh điều hướng nhỏ hơn */
    font-size: 14px; /* Thay đổi kích thước phông chữ nếu cần */
}

.logo img {
    width: 100px; /* Thay đổi kích thước của logo */
    height: auto; /* Đảm bảo tỷ lệ khung hình bảo toàn */
}

.navbar a {
    padding: 5px 10px; /* Điều chỉnh padding của các liên kết */
}

/* Điều chỉnh kích thước của biểu tượng cửa sổ đóng/mở trên di động */
.sidebar_close_icon {
    font-size: 20px;
}

</style>
<nav class="sidebar dark_sidebar active_sidebar">
<div class="logo d-flex justify-content-between">
<a class="large_logo" href="/">
    <img src="https://i.imgur.com/HCpkPFW.jpeg" alt="logo" width="auto" height="auto">
</a>
<a class="small_logo" href="/">
    <img src="https://i.imgur.com/HCpkPFW.jpeg >
<div class="sidebar_close_icon d-lg-none">
<i class="ti-close"></i>
</div>
</div>
<ul id="sidebar_menu">
<li>
<a href="index.php" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/dashboard.svg" alt>
</div>
<div class="nav_title">
<span>Trang Chủ</span>
</div>
</a>
</li>
<li>
<h4 class="menu-text"><span>Giao Dịch Viên</span> <i class="fas fa-ellipsis-h"></i> </h4>
<li class>
<a class="has-arrow" href="#" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/5.svg" alt>
</div>
<div class="nav_title">
<span>Hồ Sơ Uy Tín </span>
</div>
</a>
<ul>
<li><a href="uytin.php">Số GDV Hiện Có</a></li>
<li><a href="gdv.php">Thêm Hồ Sơ Uy Tín</a></li>
</ul>
</li>
<li class>
<a href="login.php" aria-expanded="false">
<div class="nav_icon_small">
<img src="img/menu-icon/5.svg" alt>
</div>
<div class="nav_title">
<span>Đăng Xuất</span>
</div>
</a>
</li>
</nav>
<section class="main_content dashboard_part large_header_bg">

<div class="container-fluid g-0">
<div class="row">
<div class="col-lg-12 p-0 ">
<div class="header_iner d-flex justify-content-between align-items-center">
<div class="sidebar_icon d-lg-none">
<i class="ti-menu"></i>
</div>
<label class="form-label switch_toggle d-none d-lg-block" for="checkbox">
<input type="checkbox" id="checkbox">
<div class="slider round open_miniSide"></div>
</label>
<div class="header_right d-flex justify-content-between align-items-center">
<div class="header_notification_warp d-flex align-items-center">
<li>
<div class="serach_button">
<i class="ti-search"></i>
<div class="serach_field-area d-flex align-items-center">
<div class="search_inner">
<form action="#">
<div class="search_field">
<input type="text" placeholder="Search here...">
</div>
<button class="close_search"> <i class="ti-search"></i> </button>
</form>
</div>
<span class="f_s_14 f_w_400 ml_25 white_text text_white">Apps</span>
</div>
</div>
</li>
<li>
<a class="bell_notification_clicker" href="#"> <img src="img/icon/bell.svg" alt>
<span>2</span>
</a>

<div class="Menu_NOtification_Wrap">
<div class="notification_Header">
<h4>Thông Báo</h4>
</div>
<div class="Notification_body">

<div class="single_notify d-flex align-items-center">
<div class="notify_thumb">
<a href="#"><img src="img/staf/2.png" alt></a>
</div>
<div class="notify_content">
<a href="#"><h5>Luu Gia Huy </h5></a>
<p>Cảm Ơn Bạn Đã Sử Dụng Code Của Chúng Tôi</p>
</div>
</div>
</div>
<div class="nofity_footer">
<div class="submit_button text-center pt_20">
<a href="#" class="btn_1">See More</a>
</div>
</div>
</div>

</li>
<li>
<a class="CHATBOX_open" href="#"> <img src="img/icon/msg.svg" alt> <span>2</span> </a>
</li>
</div>
<div class="profile_info">
<img src="img/client_img.png" alt="#">
<div class="profile_info_iner">
<div class="profile_author_name">
<p>Hello QTV </p>
<h5>Quản Trị Viên</h5>
</div>
<div class="profile_info_details">
<a href="login.php">Log Out </a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>