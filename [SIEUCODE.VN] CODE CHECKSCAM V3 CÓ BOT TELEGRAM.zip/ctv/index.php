<?php include('head.php');?>
<?php include('nav.php');?>

<div class="main_content_iner overly_inner ">
<div class="container-fluid p-0 ">
<?php


$sum = $tong_tien = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT SUM(`money`) FROM `cards`"));
$sum2 = $sotien = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT SUM(`sotien`) FROM `ticket` WHERE `status` = 'scam' "));
$don = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'xuly' ")) ['COUNT(*)'];
$scam = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'scam' ")) ['COUNT(*)'];
$post = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `tintuc`")) ['COUNT(*)'];
$uytin = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `cards`")) ['COUNT(*)'];
$ctv = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `usersctv`")) ['COUNT(*)'];
$dv = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `category`")) ['COUNT(*)'];

?>
<div class="row">
<div class="col-12">
<div class="page_title_box d-flex flex-wrap align-items-center justify-content-between">
<div class="page_title_left">
<h3 class="f_s_25 f_w_700 dark_text">Dashboard</h3>
<ol class="breadcrumb page_bradcam mb-0">
<li class="breadcrumb-item"><a href="javascript:void(0);">Home</a></li>
<li class="breadcrumb-item active">Trang Chủ</li>
</ol>
</div>
<div class="page_title_right">
<div class="page_date_button">
Cảm Ơn Bạn Đã Sử Dụng Code
</div>
<div class="dropdown common_bootstrap_button ">
<span class="dropdown-toggle" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
action
</span>
<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
<a class="dropdown-item f_s_16 f_w_600" href="https://touytin.io.vn"> TOUYTIN</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="row ">
<div class="col-xl-8 ">
<div class="white_card card_height_100 mb_30 social_media_card">
<div class="white_card_header">
<div class="main-title">
<h3 class="m-0">Thống Kê</h3>
<span>Danh Sách Dữ Liệu</span>
</div>
</div>
<div class="media_thumb ml_25">
<img src="img/media.svg" alt>
</div>
<div class="media_card_body">
<div class="media_card_list">
<div class="single_media_card">
<span>Số GDV</span>
<h3><?=$uytin?> User </h3>
</div>
<div class="single_media_card">
<span>Tổng Số Lừa Đảo</span>
<h3><?=$scam?> </h3>
</div>
</div>
</div>
</div>
</div>
<div class="col-xl-4 ">
<div class="white_card card_height_100 mb_30 sales_card_wrapper">
<div class="white_card_header d-flex justify-content-end">
<button class="export_btn">Export</button>
</div>

<div class="sales_card_body">
<div class="single_sales">
<span>Version</span>
<h3><?=$config['version'];?></h3>
</div>
<div class="single_sales">
<span>© Copyright</span>
<strong>TOUYTIN</strong>
</div>
<div class="single_sales">
<span>Uy Tín</span>
<h3><?=$uytin?></h3>
</div>
<div class="single_sales">
<span>Scamer</span>
<h3><?=$scam?></h3>
</div>
</div>
</div>
</div>

<div class="col-xl-12">
<div class="white_card card_height_100 mb_30 ">
<div class="row">
<div class="col-lg-9">
<div class="white_card_header">
<div class="box_header m-0">
<div class="main-title">
<h3 class="m-0">Thống Kê Số Tiền</h3>
<span>Bảng Dữ Liệu</span>
</div>
</div>
</div>
<div class="white_card_body QA_section">
<div class="QA_table ">

<table class="table lms_table_active2 p-0">
<thead>
<tr>
<th scope="col">Tên Dịch Vụ</th>
<th scope="col">Số Tiền</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<div class="customer d-flex align-items-center">
<div class="social_media">
<i class="far fa-money-bill-alt"></i>
</div>
<div class="ml_18">
<h3 class="f_s_18 f_w_900 mb-0">Số Tiền GDV</h3>
<span class="f_s_12 f_w_700 text_color_8">Tổng Số Tiền Đã Cọc</span>
</div>
</div>
</td>
<td>
<div>
<h3 class="f_s_18 f_w_800 mb-0"><?=number_format($sum['SUM(`money`)']);?> VND</h3>
<span class="f_s_12 f_w_500 color_text_3">Việt Nam Đồng</span>
</div>
</tr>
<tr>
<td>
<div class="customer d-flex align-items-center">
<div class="social_media youtube_bg">
<i class="fas fa-exclamation-triangle"></i>
</div>
<div class="ml_18">
<h3 class="f_s_18 f_w_900 mb-0">Số Tiền Scam</h3>
<span class="f_s_12 f_w_700 text_color_11">Tổng Số Tiền Scam Bị Tố Cáo</span>
</div>
</div>
</td>
<td>
<div>
<h3 class="f_s_18 f_w_800 mb-0"><?=number_format($sum2['SUM(`sotien`)']);?> VND</h3>
<span class="f_s_12 f_w_500 color_text_3">Việt Nam Đồng</span>
</div>
</tr>

</tbody>
</table>
</div>
</div>
</div>
<div class="col-lg-3 white_card_body pt_25">
<div class="project_complete">
<div class="single_pro d-flex">
<div class="probox"></div>
<div class="box_content">
<h4>CTV</h4>
<span>Tổng Số <?=$ctv?> CTV</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('foot.php');?>
